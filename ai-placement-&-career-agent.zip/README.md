# CareerAI — AI Placement & Career Intelligence Platform

[![React](https://img.shields.io/badge/React-19-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![Vite](https://img.shields.io/badge/Vite-6-646CFF?logo=vite&logoColor=white)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-v4-06B6D4?logo=tailwindcss&logoColor=white)](https://tailwindcss.com/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An intelligent, institutional-grade career guidance and placement acceleration platform. **CareerAI** bridges the gap between academic education and corporate hiring expectations by equipping engineering students with real-time placement readiness scoring, automated skill gap diagnostics, tailored learning roadmaps, curated jobs and internships, and a 24/7 AI career mentor.

---

## 🌟 Key Features

### 1. 🎓 Student Access & Authentication (`/login`)
- **University Identity Login**: Sign in directly with your University Seat Number (USN) and institutional password.
- **Google Workspace SSO**: One-click institutional Single Sign-On for campus email domains.
- **Account Registration**: Fast student onboarding capturing degree branch, year, and college details.
- **Secure Verification**: Automated OTP and institutional validation fallback for high-security campus environments.

### 2. 📊 Placement Readiness Dashboard (`/dashboard`)
- **Holistic Readiness Score**: Real-time evaluation of placement preparedness based on academics, verified skills, and project portfolio.
- **Academic Metrics**: Semester-wise CGPA trends, backlogs tracker, and internal CIE assessment performance visualized with interactive **Recharts**.
- **Quick Actions**: Instant access to top career matches, urgent skill gaps, and upcoming interview schedules.

### 3. 🧭 AI Career Matching (`/career`)
- **Profile-Driven Recommendations**: Algorithmic match percentages for roles like Full Stack Developer, DevOps Engineer, Cloud Architect, and AI/ML Engineer.
- **Market Intelligence**: Average CTC salary ranges, hiring momentum, and lists of top recruiting tech companies.

### 4. ⚡ Skill Gap Diagnostics (`/skills`)
- **Competency Heatmaps**: Visual breakdown of frontend, backend, database, DevOps, and CS fundamentals.
- **Target Gap Analysis**: Pinpoints exact discrepancies between current student skill levels and target industry standards.
- **Curated Learning Resources**: Direct course recommendations and estimated time commitments to bridge critical gaps.

### 5. 🗺️ Milestone Learning Roadmaps (`/roadmap`)
- **Phased Checklists**: Progressive milestones from CS fundamentals and data structures to microservices and system design.
- **Interactive Progress**: Check off completed learning tasks to dynamically recalculate phase and overall roadmap completion.

### 6. 💼 Curated Jobs & Internships (`/jobs`, `/applications`)
- **Placement Cell Feed**: Filter full-time opportunities and high-stipend summer/semester internships.
- **Instant Match Scores**: Match ratings showing how well your profile fits each job's required tech stack.
- **Application Tracker**: Live status updates for submitted applications (Applied, Under Review, Shortlisted, Interview Scheduled, Offer Extended).

### 7. 🤖 AI Placement Mentor & CareerBot (`/chatbot`)
- **24/7 Career Assistant**: Get instant answers regarding interview preparation, DSA strategies, resume optimization, and career transitions.
- **Floating CareerBot Widget**: Accessible directly on the landing page with pre-configured quick suggestion pills.

### 8. 👤 Comprehensive Student Profile (`/profile`)
- **Student Dossier**: Branch, semester, verified skills, academic timeline, project showcase, and certifications.
- **Resume & Links**: Integrated portfolio URLs, GitHub, LinkedIn, and resume download/preview.

---

## 🛠️ Technology Stack

| Layer | Technology |
| :--- | :--- |
| **Frontend Framework** | [React 19](https://react.dev/) + [TypeScript](https://www.typescriptlang.org/) |
| **Build Tool & Bundler**| [Vite 6](https://vitejs.dev/) |
| **Styling & Design** | [Tailwind CSS v4](https://tailwindcss.com/) with custom academic neutral themes |
| **Icons & Visuals** | [Lucide React](https://lucide.dev/) |
| **Data Visualization** | [Recharts](https://recharts.org/) |
| **Animations** | [Motion](https://motion.dev/) |
| **Routing** | [React Router DOM v7](https://reactrouter.com/) |
| **HTTP Client** | [Axios](https://axios-http.com/) with resilient automatic fallback handling |

---

## 📁 Project Structure

```text
├── .env.example               # Example environment variable declarations
├── axiois.md / axios.md       # Frontend Axios API & backend integration documentation
├── metadata.json              # Application metadata and capabilities
├── package.json               # Dependencies and build scripts
├── vite.config.ts             # Vite build configuration with Tailwind CSS plugin
├── public/                    # Static assets
└── src/
    ├── components/            # Reusable UI component library
    │   ├── charts/            # Recharts analytical components (Readiness, Skills)
    │   ├── common/            # Buttons, Cards, Badges, Modals, SearchBar, Tabs
    │   └── layout/            # Navigation bar, Sidebar slider, Page layout wrapper
    ├── context/               # Global application state (Search, Filter state)
    ├── data/                  # Curated mock dataset & graceful API fallback data
    │   └── data.js            # Comprehensive student, job, skill, and roadmap records
    ├── features/              # Modular feature domains
    │   ├── applications/      # Job & internship application status tracking
    │   ├── career/            # Career recommendations and role profiles
    │   ├── chatbot/           # AI career mentor chat interface
    │   ├── dashboard/         # Student overview dashboard & stats cards
    │   ├── jobs/              # Job and internship listings and filters
    │   ├── landing/           # Public marketing landing page and /login portal
    │   ├── notifications/     # Placement alerts and deadline reminders
    │   ├── profile/           # Student profile, academics, and portfolio
    │   ├── roadmap/           # Multi-phase milestone roadmap tracker
    │   ├── settings/          # Account, notification, and theme preferences
    │   └── skills/            # Skill audit and diagnostic gap analyzer
    ├── routes/                # Application route definitions (AppRoutes.jsx)
    ├── services/              # Axios service endpoints with auto-fallback
    │   ├── api.js             # Centralized Axios client instance
    │   ├── careerApi.js       # Career recommendations API service
    │   ├── chatbotApi.js      # AI placement chatbot API service
    │   ├── dashboardApi.js     # Student dashboard stats API service
    │   ├── jobsApi.js          # Jobs, internships, and applications API service
    │   ├── profileApi.js      # Student profile & academic records API service
    │   ├── roadmapApi.js      # Learning roadmaps and task update API service
    │   └── skillsApi.js       # Technical skills and diagnostic gap API service
    ├── index.css              # Global styling & Tailwind CSS imports
    └── main.tsx               # Application entry point
```

---

## 🚀 Getting Started

### Prerequisites
- **Node.js**: Version 18.x or 20.x+
- **Package Manager**: `npm`, `pnpm`, or `bun`

### Installation

1. **Clone or navigate to the project directory**:
   ```bash
   git clone <repository-url>
   cd career-ai
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure environment variables**:
   ```bash
   cp .env.example .env
   ```
   Edit `.env` if connecting to a dedicated backend server:
   ```env
   VITE_API_BASE_URL=http://localhost:5000/api
   ```
   *(If no backend is running, CareerAI automatically switches to its resilient built-in dataset without any errors).*

4. **Start the development server**:
   ```bash
   npm run dev
   ```
   The application will be accessible at: `http://localhost:3000`

---

## 📜 Available Scripts

| Command | Description |
| :--- | :--- |
| `npm run dev` | Starts Vite development server at port 3000 |
| `npm run build` | Compiles production assets into the `dist/` folder |
| `npm run preview` | Previews the compiled production build locally |
| `npm run lint` | Runs TypeScript static analysis (`tsc --noEmit`) |
| `npm run clean` | Cleans temporary build directories |

---

## 📡 API Documentation & Backend Integration

The frontend includes a complete Axios integration layer. Full specifications, request/response JSON schemas, and endpoint lists are documented in:
- **[`axios.md`](./axios.md)** (or [`axiois.md`](./axiois.md))

### Supported API Services:
- `GET /api/dashboard` — Aggregated student metrics & readiness overview
- `GET /api/career/recommendations` — AI-recommended roles & CTC bands
- `GET /api/skills` — Verified competencies and prioritized skill gaps
- `GET /api/roadmap` & `PATCH /api/roadmap/phase/:id/task/:id` — Milestone roadmaps
- `GET /api/jobs`, `GET /api/internships`, `POST /api/applications` — Placement opportunities
- `POST /api/chat` — Conversational AI placement mentor
- `GET /api/profile` & `PUT /api/profile` — Academic profile & portfolio details

---

## 🛡️ License

This project is open-source and available under the [MIT License](LICENSE).
