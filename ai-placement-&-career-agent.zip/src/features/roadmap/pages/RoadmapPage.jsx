import React, { useState, useEffect } from "react";
import { Map, CheckCircle2, Circle, Clock, ArrowDown, Sparkles, Plus } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { ProgressBar } from "../../../components/common/ProgressBar";
import { LoadingState } from "../../../components/common/LoadingState";
import { getRoadmap, updateTaskStatus } from "../../../services/roadmapApi";

export const RoadmapPage = () => {
  const [roadmap, setRoadmap] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getRoadmap().then((res) => {
      setRoadmap(res);
      setLoading(false);
    });
  }, []);

  const handleToggleTask = (phaseIndex, taskId) => {
    const updated = [...roadmap];
    const phase = updated[phaseIndex];
    const task = phase.tasks.find(t => t.id === taskId);
    if (task) {
      task.completed = !task.completed;
      // Recalculate progress
      const completedCount = phase.tasks.filter(t => t.completed).length;
      phase.progress = Math.round((completedCount / phase.tasks.length) * 100);
      phase.status = phase.progress === 100 ? "Completed" : phase.progress > 0 ? "In Progress" : "Not Started";
      setRoadmap(updated);
      updateTaskStatus(phase.phase, taskId, task.completed);
    }
  };

  if (loading) {
    return <LoadingState message="Loading your interactive career roadmap..." />;
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Interactive Career Roadmap"
        subtitle="Your step-by-step master plan to bridge skill gaps and master industry competencies."
        action={
          <Button variant="primary" icon={Plus}>Add Custom Milestone</Button>
        }
      />

      <div className="space-y-6 max-w-4xl mx-auto">
        {roadmap.map((phase, idx) => (
          <div key={phase.phase} className="space-y-4">
            <Card className={`border-2 transition-all ${
              phase.status === "Completed" ? "border-emerald-200 bg-emerald-50/20" :
              phase.status === "In Progress" ? "border-blue-300 bg-white shadow-md" : "border-gray-100 bg-white"
            }`}>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-4 border-b border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                    phase.status === "Completed" ? "bg-emerald-600 text-white" :
                    phase.status === "In Progress" ? "bg-blue-600 text-white" : "bg-gray-200 text-gray-700"
                  }`}>
                    {phase.phase}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-base font-bold text-gray-900">{phase.title}</h3>
                      <Badge variant={phase.status === "Completed" ? "green" : phase.status === "In Progress" ? "blue" : "gray"}>
                        {phase.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5 flex items-center">
                      <Clock className="w-3.5 h-3.5 mr-1" /> Estimated Duration: {phase.duration}
                    </p>
                  </div>
                </div>
                <div className="w-full md:w-48">
                  <ProgressBar progress={phase.progress} showLabel />
                </div>
              </div>

              {/* Skills & Tasks */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Target Skills</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {phase.skills.map((skill, sIdx) => (
                      <span key={sIdx} className="px-2.5 py-1 bg-gray-100 text-gray-700 text-xs font-medium rounded-lg">
                        {skill}
                      </span>
                    ))}
                  </div>

                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mt-4 mb-2">Projects</h4>
                  <ul className="space-y-1 text-xs text-gray-600">
                    {phase.projects.map((proj, pIdx) => (
                      <li key={pIdx} className="flex items-center">
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2" />
                        {proj}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Learning Milestone Tasks</h4>
                  <div className="space-y-2">
                    {phase.tasks.map((task) => (
                      <div
                        key={task.id}
                        onClick={() => handleToggleTask(idx, task.id)}
                        className={`flex items-center space-x-3 p-2.5 rounded-xl border transition-all cursor-pointer ${
                          task.completed
                            ? "bg-emerald-50/50 border-emerald-200 text-emerald-900"
                            : "bg-gray-50 border-gray-100 text-gray-700 hover:bg-gray-100"
                        }`}
                      >
                        {task.completed ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <Circle className="w-4 h-4 text-gray-400 shrink-0" />
                        )}
                        <span className={`text-xs font-medium ${task.completed ? "line-through opacity-80" : ""}`}>
                          {task.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* Connecting Arrow */}
            {idx < roadmap.length - 1 && (
              <div className="flex justify-center py-2">
                <div className="w-8 h-8 rounded-full bg-blue-50 border border-blue-200 flex items-center justify-center text-blue-600 shadow-xs">
                  <ArrowDown className="w-4 h-4 animate-bounce" />
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
