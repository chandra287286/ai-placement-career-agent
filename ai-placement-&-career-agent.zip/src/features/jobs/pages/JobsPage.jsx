import React, { useState, useEffect } from "react";
import { Briefcase, MapPin, Search, Building2, ExternalLink, CheckCircle, Sparkles } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { SearchBar } from "../../../components/common/SearchBar";
import { Tabs } from "../../../components/common/Tabs";
import { Modal } from "../../../components/common/Modal";
import { LoadingState } from "../../../components/common/LoadingState";
import { getJobs, getInternships, applyToOpportunity } from "../../../services/jobsApi";

export const JobsPage = () => {
  const [activeTab, setActiveTab] = useState("jobs");
  const [jobs, setJobs] = useState([]);
  const [internships, setInternships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedOpportunity, setSelectedOpportunity] = useState(null);
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [appliedStatus, setAppliedStatus] = useState({});

  useEffect(() => {
    Promise.all([getJobs(), getInternships()]).then(([jRes, iRes]) => {
      setJobs(jRes);
      setInternships(iRes);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <LoadingState message="Discovering top matching opportunities..." />;
  }

  const currentList = activeTab === "jobs" ? jobs : internships;

  const filtered = currentList.filter(item =>
    item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.location.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleApply = (oppId) => {
    applyToOpportunity(oppId);
    setAppliedStatus({ ...appliedStatus, [oppId]: true });
    setDetailModalOpen(false);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Jobs & Internships Discovery"
        subtitle="AI-matched placement opportunities curated for your tech profile."
      />

      {/* Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <Tabs
          tabs={[
            { id: "jobs", label: "Full-Time Jobs" },
            { id: "internships", label: "Internships" }
          ]}
          activeTab={activeTab}
          onChange={setActiveTab}
          className="w-full sm:w-64"
        />
        <SearchBar
          value={searchQuery}
          onChange={setSearchQuery}
          placeholder="Search role, company, location..."
          className="w-full sm:w-80"
        />
      </div>

      {/* Opportunity Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.length === 0 ? (
          <div className="col-span-2 text-center py-12 bg-white rounded-2xl border border-gray-100">
            <p className="text-sm text-gray-500">No matching opportunities found.</p>
          </div>
        ) : (
          filtered.map((opp) => {
            const isApplied = appliedStatus[opp.id];
            return (
              <Card key={opp.id} className="flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-xl ${opp.logoBg || 'bg-blue-600'} text-white font-bold flex items-center justify-center`}>
                        {opp.company[0]}
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-gray-900">{opp.company}</h4>
                        <p className="text-[10px] text-gray-500 flex items-center">
                          <MapPin className="w-3 h-3 mr-1" /> {opp.location} · {opp.workMode}
                        </p>
                      </div>
                    </div>
                    <Badge variant="blue">{opp.matchScore}% Match</Badge>
                  </div>

                  <div>
                    <h3 className="text-base font-bold text-gray-900">{opp.title}</h3>
                    <p className="text-xs text-gray-600 mt-1 line-clamp-2">{opp.description}</p>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {opp.requiredSkills.map((s, idx) => (
                      <span key={idx} className="px-2 py-0.5 bg-gray-100 text-gray-700 text-[11px] font-medium rounded-md">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <span className="text-xs font-bold text-gray-900">{opp.salary || opp.stipend}</span>
                  <div className="flex space-x-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setSelectedOpportunity(opp);
                        setDetailModalOpen(true);
                      }}
                    >
                      View Details
                    </Button>
                    <Button
                      variant={isApplied ? "success" : "primary"}
                      size="sm"
                      disabled={isApplied}
                      onClick={() => handleApply(opp.id)}
                    >
                      {isApplied ? "Applied ✓" : "Apply Now"}
                    </Button>
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>

      {/* Opportunity Detail Modal */}
      <Modal
        isOpen={detailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        title={selectedOpportunity ? selectedOpportunity.title : "Opportunity Details"}
      >
        {selectedOpportunity && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-blue-50 p-4 rounded-xl">
              <div>
                <h4 className="font-bold text-sm text-blue-900">{selectedOpportunity.company}</h4>
                <p className="text-xs text-blue-700">{selectedOpportunity.location} · {selectedOpportunity.workMode}</p>
              </div>
              <Badge variant="blue">{selectedOpportunity.matchScore}% Match</Badge>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1">Compensation</h4>
              <p className="text-base font-black text-gray-900">{selectedOpportunity.salary || selectedOpportunity.stipend}</p>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Job Description</h4>
              <p className="text-xs text-gray-700 leading-relaxed">{selectedOpportunity.description}</p>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Required Skills</h4>
              <div className="flex flex-wrap gap-2">
                {selectedOpportunity.requiredSkills.map((s, idx) => (
                  <span key={idx} className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-lg">
                    ✓ {s}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100 flex justify-end space-x-3">
              <Button variant="secondary" onClick={() => setDetailModalOpen(false)}>Close</Button>
              <Button
                variant={appliedStatus[selectedOpportunity.id] ? "success" : "primary"}
                onClick={() => handleApply(selectedOpportunity.id)}
              >
                {appliedStatus[selectedOpportunity.id] ? "Applied ✓" : "Apply Now"}
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
