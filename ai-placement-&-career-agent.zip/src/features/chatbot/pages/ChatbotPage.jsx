import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, User, Bot, Compass, Cpu, Map, Award } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { Avatar } from "../../../components/common/Avatar";
import { initialChatMessages, studentProfile, dashboardStats, careerRecommendations } from "../../../data/data";
import { sendMessage } from "../../../services/chatbotApi";

export const ChatbotPage = () => {
  const [messages, setMessages] = useState(initialChatMessages);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSend = async (textToSend) => {
    const text = textToSend || inputMessage;
    if (!text.trim()) return;

    const userMsg = {
      id: Date.now().toString(),
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputMessage("");
    setIsTyping(true);

    const res = await sendMessage(text);

    setIsTyping(false);
    const aiMsg = {
      id: (Date.now() + 1).toString(),
      sender: "ai",
      text: res.reply,
      timestamp: res.timestamp
    };

    setMessages((prev) => [...prev, aiMsg]);
  };

  const suggestedPrompts = [
    "What career is best for me?",
    "How can I improve my skill gap?",
    "Create a roadmap for Full Stack Development",
    "What should I learn before placements?",
    "Review my resume",
    "Find suitable internships"
  ];

  return (
    <div className="space-y-6 animate-fade-in h-[calc(100vh-8rem)] flex flex-col">
      <PageHeader
        title="AI Career Assistant"
        subtitle="Your 24/7 personal AI mentor for interview prep, resume optimization, and roadmap guidance."
      />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-0">
        {/* Left: Chat Conversation Area */}
        <Card className="lg:col-span-8 flex flex-col p-0 overflow-hidden h-full">
          {/* Chat Header */}
          <div className="p-4 bg-gray-50 border-b border-gray-100 flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-gray-900">CareerAgent AI Mentor</h3>
              <p className="text-[10px] text-emerald-600 font-medium flex items-center">
                <span className="w-2 h-2 rounded-full bg-emerald-500 mr-1.5 animate-pulse" /> Online & Ready
              </p>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/40">
            {messages.map((msg) => {
              const isAi = msg.sender === "ai";
              return (
                <div key={msg.id} className={`flex items-start space-x-3 ${isAi ? "" : "flex-row-reverse space-x-reverse"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                    isAi ? "bg-blue-600 text-white" : "bg-gray-800 text-white"
                  }`}>
                    {isAi ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </div>
                  <div className={`max-w-[80%] rounded-2xl p-4 text-xs leading-relaxed shadow-xs ${
                    isAi ? "bg-white text-gray-800 border border-gray-100" : "bg-blue-600 text-white"
                  }`}>
                    <div className="whitespace-pre-wrap">{msg.text}</div>
                    <p className={`text-[9px] mt-2 text-right ${isAi ? "text-gray-400" : "text-blue-100"}`}>{msg.timestamp}</p>
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-white border border-gray-100 rounded-2xl p-3 text-xs text-gray-400 flex items-center space-x-1.5">
                  <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" />
                  <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-2 h-2 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Suggested Prompts */}
          <div className="p-3 bg-white border-t border-gray-100 flex overflow-x-auto space-x-2 scrollbar-none">
            {suggestedPrompts.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(prompt)}
                className="px-3 py-1.5 bg-gray-50 hover:bg-blue-50 hover:text-blue-600 border border-gray-200 rounded-full text-xs font-medium text-gray-600 whitespace-nowrap transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="p-3 bg-white border-t border-gray-100 flex items-center space-x-2">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask anything about careers, skills, or interviews..."
              className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white"
            />
            <Button variant="primary" onClick={() => handleSend()} icon={Send}>
              Send
            </Button>
          </div>
        </Card>

        {/* Right: Career Context Sidebar */}
        <div className="hidden lg:flex lg:col-span-4 flex-col space-y-4">
          <Card className="space-y-4">
            <h4 className="font-bold text-xs text-gray-400 uppercase tracking-wider">Live Student Context</h4>
            <div className="space-y-3 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-500">Student Name</span>
                <span className="font-bold text-gray-900">{studentProfile.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Branch & CGPA</span>
                <span className="font-bold text-gray-900">CSE · {studentProfile.cgpa}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Top Career Match</span>
                <span className="font-bold text-blue-600">{careerRecommendations[0].title} ({careerRecommendations[0].matchScore}%)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Overall Skill Score</span>
                <span className="font-bold text-emerald-600">{dashboardStats.skillScore}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Placement Readiness</span>
                <span className="font-bold text-purple-600">{dashboardStats.placementReadiness}%</span>
              </div>
            </div>
          </Card>

          <Card className="bg-blue-50/50 border-blue-100 space-y-3">
            <div className="flex items-center space-x-2 text-blue-900 font-bold text-xs">
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>Prompting Tips</span>
            </div>
            <p className="text-xs text-gray-600 leading-relaxed">
              Ask specific questions like "What are the core React interview questions for Zomato?" or "Review my project list" for instant AI intelligence.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
};
