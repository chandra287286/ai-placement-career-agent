import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Award, CheckCircle2, TrendingUp, Cpu, Compass, ArrowRight, Sparkles, Briefcase } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { StatCard } from "../../../components/common/StatCard";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { ProgressBar } from "../../../components/common/ProgressBar";
import { LoadingState } from "../../../components/common/LoadingState";
import { getDashboard } from "../../../services/dashboardApi";
import { useAuth } from "../../../context/AuthContext";

export const DashboardPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getDashboard().then((res) => {
      setData(res);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <LoadingState message="Loading your career intelligence overview..." />;
  }

  const { stats, recommendedCareer, skillGaps, roadmapProgress, recommendedOpportunities } = data;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Greeting Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-gray-900">Good Morning, {user.name.split(" ")[0]} 👋</h1>
          <p className="text-sm text-gray-500 mt-1">Here's your real-time career intelligence & placement readiness overview.</p>
        </div>
        <Button variant="primary" onClick={() => navigate("/career")} icon={Sparkles}>
          Explore AI Recommendations
        </Button>
      </div>

      {/* Statistic Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard
          title="Placement Readiness"
          value={`${stats.placementReadiness}%`}
          change={stats.readinessGrowth}
          icon={Award}
          color="blue"
        />
        <StatCard
          title="Profile Completion"
          value={`${user.profileCompletion}%`}
          subtitle="Complete resume & projects"
          icon={CheckCircle2}
          color="green"
        />
        <StatCard
          title="Career Match"
          value={`${stats.careerMatch}%`}
          subtitle="Full Stack Developer"
          icon={Compass}
          color="purple"
        />
        <StatCard
          title="Skill Score"
          value={`${stats.skillScore}%`}
          change={stats.skillScoreGrowth}
          icon={Cpu}
          color="amber"
        />
      </div>

      {/* Main Grid: Recommended Career & Skill Gap */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Recommended Career Card */}
        <Card leftAccent="teal" className="lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-[#8A918C] tracking-wider uppercase">Recommended Career</span>
              <Badge variant="teal">{recommendedCareer.matchScore}% Match</Badge>
            </div>
            <h3 className="text-xl font-bold text-[#1F2421] mb-2">{recommendedCareer.title}</h3>
            <p className="text-xs text-[#626A65] mb-6 leading-relaxed">{recommendedCareer.description}</p>
            <div className="space-y-2 mb-6">
              <p className="text-xs font-semibold text-[#555D58]">Based on your proficiency in:</p>
              <div className="flex flex-wrap gap-2">
                {recommendedCareer.requiredSkills.slice(0, 4).map((skill, idx) => (
                  <span key={idx} className="inline-flex items-center px-2.5 py-1 rounded-lg bg-[#EAF8F2] text-[#159A72] text-xs font-medium border border-[#159A72]/20">
                    ✓ {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
          <Button variant="primary" onClick={() => navigate("/career")} icon={ArrowRight}>
            View Recommendation
          </Button>
        </Card>

        {/* Skill Gap Summary */}
        <Card leftAccent="amber" className="lg:col-span-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-[#8A918C] tracking-wider uppercase">Skill Gap Priority</span>
              <span className="text-xs font-semibold text-[#C94B4B]">3 Critical Gaps</span>
            </div>
            <p className="text-xs text-[#626A65] mb-4">Closing these gaps will increase your placement match score by +14%.</p>
            <div className="space-y-4 mb-6">
              {skillGaps.slice(0, 3).map((gap, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between text-xs font-semibold">
                    <span className="text-[#1F2421]">{gap.skill}</span>
                    <span className="text-[#8A918C]">{gap.currentLevel}% / {gap.requiredLevel}%</span>
                  </div>
                  <ProgressBar progress={gap.currentLevel} color={gap.currentLevel < 50 ? "rose" : "amber"} />
                </div>
              ))}
            </div>
          </div>
          <Button variant="secondary" onClick={() => navigate("/skills")} icon={ArrowRight}>
            View Complete Skill Gap
          </Button>
        </Card>
      </div>

      {/* Second Grid: Roadmap Progress & AI Insight */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Career Roadmap Progress */}
        <Card leftAccent="blue" className="lg:col-span-7">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-[#1F2421]">Career Roadmap Progress</h3>
            <button onClick={() => navigate("/roadmap")} className="text-xs font-semibold text-[#087F73] hover:underline">
              View All Phases
            </button>
          </div>
          <div className="space-y-4">
            {roadmapProgress.map((phase, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 rounded-xl bg-[#F7F6F2] border border-[#E7E4DC]">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                    phase.status === "Completed" ? "bg-[#EAF8F2] text-[#159A72]" :
                    phase.status === "In Progress" ? "bg-[#EEF4FA] text-[#4F7CAC]" : "bg-[#E7E4DC] text-[#626A65]"
                  }`}>
                    {phase.status === "Completed" ? "✓" : phase.progress}%
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#1F2421]">{phase.phase}. {phase.title}</h4>
                    <p className="text-[10px] text-[#8A918C]">{phase.duration} · {phase.status}</p>
                  </div>
                </div>
                <Badge variant={phase.status === "Completed" ? "green" : phase.status === "In Progress" ? "blue" : "gray"}>
                  {phase.status}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* AI Insight Card */}
        <Card className="lg:col-span-5 bg-gradient-to-br from-indigo-900 to-blue-900 text-white flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center space-x-2 text-blue-300 text-xs font-semibold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>AI Placement Intelligence</span>
            </div>
            <p className="text-sm leading-relaxed text-blue-50 font-medium italic">
              "Your strongest path right now is Full Stack Development. Improving backend and cloud skills could significantly increase your placement readiness to 90%+."
            </p>
          </div>
          <div className="pt-6">
            <Button
              variant="secondary"
              className="w-full bg-white/10 text-white border-white/20 hover:bg-white/20"
              onClick={() => navigate("/assistant")}
            >
              Ask AI Assistant
            </Button>
          </div>
        </Card>
      </div>

      {/* Recommended Opportunities */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-gray-900">Recommended Opportunities</h3>
          <button onClick={() => navigate("/jobs")} className="text-xs font-semibold text-blue-600 hover:underline">
            View All Jobs & Internships
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendedOpportunities.map((opp) => (
            <div key={opp.id} className="p-4 rounded-xl border border-gray-100 hover:border-blue-200 transition-colors bg-white space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-50 text-blue-700">{opp.matchScore}% Match</span>
                <span className="text-xs text-gray-400">{opp.workMode}</span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900">{opp.title}</h4>
                <p className="text-xs text-gray-500">{opp.company} · {opp.location}</p>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                <span className="text-xs font-bold text-gray-900">{opp.salary || opp.stipend}</span>
                <Button size="sm" variant="outline" onClick={() => navigate("/jobs")}>
                  View
                </Button>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
