import React, { useState } from "react";
import { Settings, User, Bell, Lock, Shield, LogOut, CheckCircle } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { useAuth } from "../../../context/AuthContext";
import { useNavigate } from "react-router-dom";

export const SettingsPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [saved, setSaved] = useState(false);
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [pushAlerts, setPushAlerts] = useState(true);
  const [profilePublic, setProfilePublic] = useState(true);

  const handleSave = (e) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto animate-fade-in">
      <PageHeader
        title="Account Settings"
        subtitle="Manage your platform preferences, privacy, notification channels, and account security."
      />

      {saved && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center space-x-3 text-xs text-emerald-800 font-semibold animate-fade-in">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>Settings successfully updated and saved!</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6">
        {/* Account Details */}
        <Card className="space-y-4">
          <h3 className="text-base font-bold text-gray-900 flex items-center">
            <User className="w-5 h-5 mr-2 text-blue-600" /> Account Information
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block font-semibold text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                defaultValue={user.name}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-gray-700 mb-1">Email Address</label>
              <input
                type="email"
                defaultValue={user.email}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </Card>

        {/* Notification Preferences */}
        <Card className="space-y-4">
          <h3 className="text-base font-bold text-gray-900 flex items-center">
            <Bell className="w-5 h-5 mr-2 text-blue-600" /> Notification Preferences
          </h3>
          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
              <div>
                <span className="font-bold text-gray-900 block">Email Notifications</span>
                <span className="text-gray-500 text-[10px]">Receive daily job matches and AI roadmap milestone alerts</span>
              </div>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>
            <label className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
              <div>
                <span className="font-bold text-gray-900 block">Push Notifications</span>
                <span className="text-gray-500 text-[10px]">Get real-time browser alerts for interview updates</span>
              </div>
              <input
                type="checkbox"
                checked={pushAlerts}
                onChange={(e) => setPushAlerts(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>
          </div>
        </Card>

        {/* Privacy & Visibility */}
        <Card className="space-y-4">
          <h3 className="text-base font-bold text-gray-900 flex items-center">
            <Shield className="w-5 h-5 mr-2 text-blue-600" /> Privacy & Placement Visibility
          </h3>
          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 bg-gray-50 rounded-xl cursor-pointer">
              <div>
                <span className="font-bold text-gray-900 block">Public Student Profile</span>
                <span className="text-gray-500 text-[10px]">Allow verified college placement officers and recruiters to view your resume & skills</span>
              </div>
              <input
                type="checkbox"
                checked={profilePublic}
                onChange={(e) => setProfilePublic(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
              />
            </label>
          </div>
        </Card>

        {/* Save & Logout Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <Button
            variant="danger"
            onClick={() => {
              logout();
              navigate("/");
            }}
            icon={LogOut}
          >
            Sign Out
          </Button>
          <Button variant="primary" type="submit">
            Save Preferences
          </Button>
        </div>
      </form>
    </div>
  );
};
