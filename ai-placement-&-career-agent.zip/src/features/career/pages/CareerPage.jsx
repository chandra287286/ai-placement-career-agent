import React, { useState, useEffect } from "react";
import { Compass, Sparkles, ArrowRight, CheckCircle, AlertCircle, Layers } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { Modal } from "../../../components/common/Modal";
import { LoadingState } from "../../../components/common/LoadingState";
import { CareerMatchChart } from "../../../components/charts/CareerMatchChart";
import { getCareerRecommendations } from "../../../services/careerApi";

export const CareerPage = () => {
  const [careers, setCareers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCareer, setSelectedCareer] = useState(null);
  const [exploreModalOpen, setExploreModalOpen] = useState(false);

  useEffect(() => {
    getCareerRecommendations().then((res) => {
      setCareers(res);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <LoadingState message="Analyzing AI career recommendations..." />;
  }

  const handleExplore = (career) => {
    setSelectedCareer(career);
    setExploreModalOpen(true);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="AI Career Recommendations"
        subtitle="AI-curated career paths matched to your technical profile, project history, and industry demand."
      />

      {/* Overview Chart Banner */}
      <Card className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-5 space-y-4">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 mr-1.5" /> AI Profile Analysis
          </div>
          <h2 className="text-xl font-bold text-gray-900">Your Highest Career Fit: Full Stack Developer</h2>
          <p className="text-xs text-gray-600 leading-relaxed">
            Your 90% proficiency in React and solid database fundamentals position you in the top 10% of engineering candidates for full-stack and frontend roles.
          </p>
        </div>
        <div className="lg:col-span-7">
          <CareerMatchChart />
        </div>
      </Card>

      {/* Career Comparison Table */}
      <Card>
        <h3 className="text-base font-bold text-gray-900 mb-4">Career Path Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-500 uppercase font-semibold">
              <tr>
                <th className="px-4 py-3">Career Title</th>
                <th className="px-4 py-3">Match Score</th>
                <th className="px-4 py-3">Salary Range</th>
                <th className="px-4 py-3">Demand Level</th>
                <th className="px-4 py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {careers.map((c) => (
                <tr key={c.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-3 font-bold text-gray-900">{c.title}</td>
                  <td className="px-4 py-3">
                    <Badge variant={c.matchScore >= 90 ? "green" : c.matchScore >= 80 ? "blue" : "amber"}>
                      {c.matchScore}% Match
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-gray-600 font-semibold">{c.salaryRange}</td>
                  <td className="px-4 py-3">
                    <span className="font-medium text-gray-700">{c.demand}</span>
                  </td>
                  <td className="px-4 py-3">
                    <button
                      onClick={() => handleExplore(c)}
                      className="text-blue-600 hover:text-blue-800 font-semibold flex items-center"
                    >
                      Explore <ArrowRight className="w-3.5 h-3.5 ml-1" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Career Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {careers.map((c) => (
          <Card key={c.id} className="flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-gray-400 uppercase">Career Track</span>
                <Badge variant="blue">{c.matchScore}% Match</Badge>
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900">{c.title}</h3>
                <p className="text-xs text-blue-600 font-semibold mt-1">{c.salaryRange} · Demand: {c.demand}</p>
                <p className="text-xs text-gray-600 mt-2 leading-relaxed">{c.description}</p>
              </div>

              {/* Skill Breakdown */}
              <div className="space-y-2 pt-2 border-t border-gray-100">
                <p className="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Skill Match Breakdown</p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>Frontend: <span className="font-bold text-gray-900">{c.skillBreakdown.frontend}%</span></div>
                  <div>Backend: <span className="font-bold text-gray-900">{c.skillBreakdown.backend}%</span></div>
                  <div>Database: <span className="font-bold text-gray-900">{c.skillBreakdown.database}%</span></div>
                  <div>Cloud: <span className="font-bold text-gray-900">{c.skillBreakdown.cloud}%</span></div>
                </div>
              </div>

              {/* Missing Skills */}
              {c.missingSkills && c.missingSkills.length > 0 && (
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-rose-600 uppercase tracking-wider">Missing Skills to Learn</p>
                  <div className="flex flex-wrap gap-1.5">
                    {c.missingSkills.map((ms, idx) => (
                      <span key={idx} className="px-2 py-0.5 bg-rose-50 text-rose-700 text-[11px] font-medium rounded-md">
                        {ms}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Button variant="primary" onClick={() => handleExplore(c)} icon={ArrowRight}>
              Explore Career
            </Button>
          </Card>
        ))}
      </div>

      {/* Explore Career Modal */}
      <Modal
        isOpen={exploreModalOpen}
        onClose={() => setExploreModalOpen(false)}
        title={selectedCareer ? `Career Insights: ${selectedCareer.title}` : "Career Insights"}
      >
        {selectedCareer && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-blue-50 p-4 rounded-xl">
              <div>
                <p className="text-xs font-bold text-blue-900">Overall Match Score</p>
                <p className="text-2xl font-black text-blue-600 mt-0.5">{selectedCareer.matchScore}%</p>
              </div>
              <div className="text-right">
                <p className="text-xs font-bold text-blue-900">Estimated Salary</p>
                <p className="text-sm font-bold text-gray-900 mt-0.5">{selectedCareer.salaryRange}</p>
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Description</h4>
              <p className="text-xs text-gray-700 leading-relaxed">{selectedCareer.description}</p>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Top Hiring Companies</h4>
              <div className="flex flex-wrap gap-2">
                {selectedCareer.topCompanies.map((comp, idx) => (
                  <span key={idx} className="px-3 py-1 bg-gray-100 text-gray-800 text-xs font-semibold rounded-lg">
                    {comp}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Required Skills</h4>
              <div className="flex flex-wrap gap-2">
                {selectedCareer.requiredSkills.map((req, idx) => (
                  <span key={idx} className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-semibold rounded-lg">
                    ✓ {req}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100 flex justify-end">
              <Button variant="primary" onClick={() => setExploreModalOpen(false)}>
                Close Insights
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
