import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Sparkles, ArrowRight, CheckCircle2, ShieldCheck, Mail, Lock, User, GraduationCap } from "lucide-react";

export const LoginPage = () => {
  const navigate = useNavigate();
  const [isRegister, setIsRegister] = useState(false);
  const [usn, setUsn] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/dashboard");
  };

  const handleGoogleLogin = () => {
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen bg-[#F7F6F2] flex items-center justify-center p-4 sm:p-6 font-sans">
      <div className="max-w-5xl w-full bg-white rounded-3xl shadow-[0_12px_40px_rgba(30,40,35,0.08)] border border-[#E7E4DC] grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
        
        {/* Left Informational Column (Mirrors Reference Clean Style) */}
        <div className="lg:col-span-5 bg-[#EAF7F3]/60 p-8 sm:p-12 flex flex-col justify-between border-r border-[#E7E4DC]">
          <div className="space-y-6">
            <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-white text-[#087F73] text-xs font-bold border border-[#087F73]/20 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 mr-1.5" /> Student & Career Access
            </div>
            
            <h1 className="text-3xl sm:text-4xl font-black text-[#1F2421] tracking-tight leading-[1.15]">
              Student access, <br />
              <span className="text-[#087F73]">without chaos.</span>
            </h1>

            <p className="text-[#626A65] text-xs sm:text-sm leading-relaxed">
              Access attendance, placement roadmaps, AI skill gap analysis, and CIE marks. Your USN is your secure identity.
            </p>

            <div className="space-y-3.5 pt-4">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 rounded-full bg-white text-[#087F73] flex items-center justify-center font-bold text-xs shrink-0 shadow-xs mt-0.5">✓</div>
                <div>
                  <h4 className="font-bold text-xs text-[#1F2421]">Track your placement readiness</h4>
                  <p className="text-[11px] text-[#626A65]">Real-time AI updates and recruiter match alerts</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 rounded-full bg-white text-[#087F73] flex items-center justify-center font-bold text-xs shrink-0 shadow-xs mt-0.5">✓</div>
                <div>
                  <h4 className="font-bold text-xs text-[#1F2421]">View CIE & Tech Assessments</h4>
                  <p className="text-[11px] text-[#626A65]">Internal test scores and coding evaluations in one place</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 rounded-full bg-white text-[#087F73] flex items-center justify-center font-bold text-xs shrink-0 shadow-xs mt-0.5">✓</div>
                <div>
                  <h4 className="font-bold text-xs text-[#1F2421]">AI Career Assistant</h4>
                  <p className="text-[11px] text-[#626A65]">24/7 interview prep and personalized roadmaps</p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-8">
            <Link to="/" className="text-xs font-bold text-[#087F73] hover:underline flex items-center">
              ← Back to CareerAI Home
            </Link>
          </div>
        </div>

        {/* Right Form Column */}
        <div className="lg:col-span-7 p-8 sm:p-12 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#087F73] flex items-center justify-center text-white shadow-xs">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <span className="font-bold text-base text-[#1F2421]">CareerAI Portal</span>
              </div>
              <div className="flex items-center bg-[#F7F6F2] p-1 rounded-xl border border-[#E7E4DC] text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setIsRegister(false)}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${!isRegister ? "bg-white text-[#087F73] shadow-xs" : "text-[#626A65]"}`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setIsRegister(true)}
                  className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${isRegister ? "bg-white text-[#087F73] shadow-xs" : "text-[#626A65]"}`}
                >
                  Register
                </button>
              </div>
            </div>

            <div className="mb-6">
              <h2 className="text-2xl font-black text-[#1F2421] tracking-tight">
                {isRegister ? "Create Student Account" : "Student Access"}
              </h2>
              <p className="text-xs text-[#626A65] mt-1">
                {isRegister ? "Register with your USN and college credentials." : "Access your student dashboard and placement records."}
              </p>
            </div>

            {/* Google SSO Button */}
            <button
              type="button"
              onClick={handleGoogleLogin}
              className="w-full mb-6 flex items-center justify-center space-x-3 py-2.5 px-4 bg-white hover:bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs font-bold text-[#1F2421] shadow-xs transition-all cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
              </svg>
              <span>Continue with Google Workspace</span>
            </button>

            <div className="relative flex items-center justify-center mb-6">
              <div className="border-t border-[#E7E4DC] w-full" />
              <span className="absolute bg-white px-3 text-[10px] font-bold text-[#8A918C] uppercase tracking-wider">or continue with usn</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {isRegister && (
                <div>
                  <label className="block text-xs font-bold text-[#1F2421] mb-1">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A918C]" />
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Arjun Reddy"
                      className="w-full pl-10 pr-4 py-2.5 bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
                    />
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[#1F2421] mb-1">University / USN</label>
                <div className="relative">
                  <GraduationCap className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A918C]" />
                  <input
                    type="text"
                    required
                    value={usn}
                    onChange={(e) => setUsn(e.target.value)}
                    placeholder="e.g. 1EP24CS001"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1F2421] mb-1">Student College Email</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A918C]" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. arjun@epcet.edu.in"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#1F2421] mb-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A918C]" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
                  />
                </div>
              </div>

              <div className="p-3 bg-[#FFF6DF] border border-[#D99A24]/30 rounded-xl flex items-start space-x-2.5 text-[11px] text-[#8C6212]">
                <ShieldCheck className="w-4 h-4 text-[#D99A24] shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold">Secure University Verification:</strong> OTP or institutional validation will be triggered if login credentials fail.
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#1F2421] hover:bg-[#087F73] text-white rounded-xl font-bold text-xs transition-all duration-300 shadow-md cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>{isRegister ? "Complete Student Registration" : "Continue to Student Dashboard"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          </div>

          <div className="pt-6 text-center text-xs text-[#8A918C]">
            Having trouble? <a href="#" className="text-[#087F73] font-semibold hover:underline">Contact your college admin</a>
          </div>
        </div>

      </div>
    </div>
  );
};
