import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Sparkles, ArrowRight, CheckCircle2, Compass, Cpu, Map, Briefcase, MessageSquareCode, TrendingUp, Bot, Send, X, Smile } from "lucide-react";
import { Button } from "../../../components/common/Button";
import { Card } from "../../../components/common/Card";
import { Badge } from "../../../components/common/Badge";

export const LandingPage = () => {
  const [activeTab, setActiveTab] = useState("fullstack");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState([
    { sender: "bot", text: "Hi! I'm CareerBot 🤖, your AI placement mentor. Ask me anything about career tracks, skill gaps, or placements!" }
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userText = inputMessage;
    const newMessages = [...chatMessages, { sender: "user", text: userText }];
    setChatMessages(newMessages);
    setInputMessage("");

    // Simulate cute robot AI reply
    setTimeout(() => {
      let botReply = "That's a fantastic career question! Our AI placement dashboard can analyze your exact tech stack and guide you step-by-step. Click 'Explore Career Dashboard' above to get started!";
      const lower = userText.toLowerCase();
      if (lower.includes("cgpa") || lower.includes("gpa")) {
        botReply = "Your academic CGPA of 8.4 is solid! Combined with your React & Node projects, you are at 94% placement readiness for tier-1 tech companies.";
      } else if (lower.includes("job") || lower.includes("placement") || lower.includes("hire")) {
        botReply = "We partner with top product companies for campus drives and off-campus placements. Check out the Jobs tab in the student dashboard!";
      } else if (lower.includes("workshop") || lower.includes("offline")) {
        botReply = "Our offline institutional workshops cover advanced system design, DSA, and mock coding interviews directly on campus!";
      }

      setChatMessages(prev => [...prev, { sender: "bot", text: botReply }]);
    }, 600);
  };

  const categoryModules = {
    fullstack: [
      { title: "Full Stack & React Specialization", level: "Intermediate", duration: "6 – 8 weeks", desc: "Master modern React, Node.js, Express, and PostgreSQL microservices for placement success.", badge: "Popular" },
      { title: "Advanced System Design & Scalability", level: "Advanced", duration: "4 – 6 weeks", desc: "Learn load balancers, caching, distributed transactions, and high-concurrency architecture.", badge: "Critical" }
    ],
    ai: [
      { title: "Machine Learning & AI Integration", level: "Intermediate", duration: "8 – 10 weeks", desc: "Build predictive models, NLP pipelines, and integrate Gemini APIs into web applications.", badge: "Trending" },
      { title: "Data Structures & LeetCode Mastery", level: "All Levels", duration: "12 weeks", desc: "Master algorithmic patterns, graph theory, dynamic programming, and interview coding rounds.", badge: "Essential" }
    ],
    cloud: [
      { title: "AWS & Cloud Infrastructure", level: "Beginner", duration: "4 – 6 weeks", desc: "EC2, S3, IAM, Serverless architecture, and CI/CD deployment pipelines for cloud engineers.", badge: "High Demand" },
      { title: "DevOps & Docker Containerization", level: "Advanced", duration: "6 weeks", desc: "Docker, Kubernetes, GitHub Actions, and automated monitoring for modern software teams.", badge: "Advanced" }
    ],
    core: [
      { title: "Core CS Fundamentals (OS, DBMS, CN)", level: "Comprehensive", duration: "6 weeks", desc: "Essential computer science theory required for cracking top-tier product company interviews.", badge: "Core" }
    ]
  };

  return (
    <div className="min-h-screen bg-[#F7F6F2] text-[#1F2421] font-sans relative">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-[#E7E4DC]">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#087F73] flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="font-extrabold text-xl tracking-tight text-[#1F2421]">
              CareerAI
            </span>
          </div>
          <div className="hidden md:flex items-center space-x-8 text-sm font-semibold text-[#626A65]">
            <a href="#features" className="hover:text-[#087F73] transition-colors">Features</a>
            <a href="#how-it-works" className="hover:text-[#087F73] transition-colors">How It Works</a>
            <a href="#curriculum" className="hover:text-[#087F73] transition-colors">Programs</a>
            <a href="#intelligence" className="hover:text-[#087F73] transition-colors">AI Intelligence</a>
          </div>
          <div className="flex items-center space-x-3">
            <Link to="/login">
              <Button variant="secondary" size="md">
                Sign In
              </Button>
            </Link>
            <Link to="/dashboard">
              <Button variant="primary" size="md" icon={ArrowRight}>
                Student Dashboard
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-16 pb-24 px-6 overflow-hidden bg-gradient-to-b from-[#F7F6F2] via-white to-[#F7F6F2]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center px-3.5 py-1.5 rounded-full bg-[#FFF6DF] text-[#D99A24] text-xs font-bold border border-[#D99A24]/30 shadow-xs">
              ★ AI Placement & Career Intelligence for Students
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-[#1F2421] tracking-tight leading-[1.15]">
              Transforming <span className="text-[#087F73]">Academic Skills</span> <br />
              Building <span className="text-[#4F7CAC]">Careers</span>
            </h1>
            <p className="text-[#626A65] text-base sm:text-lg max-w-xl mx-auto lg:mx-0 leading-relaxed">
              From classroom to corporate placement, equipping tomorrow’s tech leaders with <strong className="text-[#1F2421]">essential industry skills</strong>, precise AI gap analysis, and real-world career roadmaps.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <Link to="/dashboard" className="w-full sm:w-auto">
                <Button variant="primary" size="lg" className="w-full sm:w-auto shadow-sm" icon={ArrowRight}>
                  Explore Career Dashboard
                </Button>
              </Link>
              <a href="#curriculum" className="w-full sm:w-auto">
                <Button variant="secondary" size="lg" className="w-full sm:w-auto">
                  View Programs →
                </Button>
              </a>
            </div>
            <div className="pt-4 flex items-center justify-center lg:justify-start space-x-6 text-xs font-semibold text-[#555D58]">
              <div className="flex items-center"><CheckCircle2 className="w-4 h-4 text-[#159A72] mr-1.5" /> 94% Placement Readiness</div>
              <div className="flex items-center"><CheckCircle2 className="w-4 h-4 text-[#159A72] mr-1.5" /> Real-Time Gemini AI</div>
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white rounded-2xl p-5 border border-[#E7E4DC] shadow-[0_4px_16px_rgba(30,40,35,0.06)] space-y-3 hover:border-[#087F73] transition-all">
              <div className="flex justify-between items-center">
                <Badge variant="teal">AI Analysis</Badge>
                <span className="text-[10px] text-[#8A918C]">Live Sync</span>
              </div>
              <div className="h-28 bg-[#EAF7F3] rounded-xl flex items-center justify-center border border-[#087F73]/20 relative overflow-hidden">
                <Compass className="w-12 h-12 text-[#087F73] animate-pulse" />
              </div>
              <h4 className="font-bold text-sm text-[#1F2421]">Smart Career Matcher</h4>
              <p className="text-xs text-[#626A65]">Matches your tech stack with top engineering roles instantly.</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E7E4DC] shadow-[0_4px_16px_rgba(30,40,35,0.06)] space-y-3 hover:border-[#D99A24] transition-all">
              <div className="flex justify-between items-center">
                <Badge variant="amber">Skill Gaps</Badge>
                <span className="text-[10px] text-[#8A918C]">Prioritized</span>
              </div>
              <div className="h-28 bg-[#FFF6DF] rounded-xl flex items-center justify-center border border-[#D99A24]/30 relative overflow-hidden">
                <Cpu className="w-12 h-12 text-[#D99A24]" />
              </div>
              <h4 className="font-bold text-sm text-[#1F2421]">Skill Gap Diagnostics</h4>
              <p className="text-xs text-[#626A65]">Pinpoints missing competencies with recommended courses.</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E7E4DC] shadow-[0_4px_16px_rgba(30,40,35,0.06)] space-y-3 hover:border-[#4F7CAC] transition-all">
              <div className="flex justify-between items-center">
                <Badge variant="blue">Roadmaps</Badge>
                <span className="text-[10px] text-[#8A918C]">Interactive</span>
              </div>
              <div className="h-28 bg-[#EEF4FA] rounded-xl flex items-center justify-center border border-[#4F7CAC]/20 relative overflow-hidden">
                <Map className="w-12 h-12 text-[#4F7CAC]" />
              </div>
              <h4 className="font-bold text-sm text-[#1F2421]">Milestone Roadmaps</h4>
              <p className="text-xs text-[#626A65]">Step-by-step guidance from beginner to interview readiness.</p>
            </div>

            <div className="bg-white rounded-2xl p-5 border border-[#E7E4DC] shadow-[0_4px_16px_rgba(30,40,35,0.06)] space-y-3 hover:border-[#159A72] transition-all">
              <div className="flex justify-between items-center">
                <Badge variant="green">Placements</Badge>
                <span className="text-[10px] text-[#8A918C]">Workshops</span>
              </div>
              <div className="h-28 bg-[#EAF8F2] rounded-xl flex items-center justify-center border border-[#159A72]/20 relative overflow-hidden">
                <Briefcase className="w-12 h-12 text-[#159A72]" />
              </div>
              <h4 className="font-bold text-sm text-[#1F2421]">Institution Cell Training</h4>
              <p className="text-xs text-[#626A65]">Mock interviews, resume building, and direct recruiter portals.</p>
            </div>
          </div>

        </div>
      </section>

      {/* What We Do Section */}
      <section className="py-24 px-6 bg-white border-y border-[#E7E4DC]">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-bold tracking-widest text-[#087F73] uppercase">Institutional Excellence</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-[#1F2421] tracking-tight">
              What We Do at <span className="text-[#087F73]">CareerAI</span>
            </h2>
            <p className="text-[#626A65] text-base leading-relaxed">
              We empower universities, engineering departments, and ambitious students through comprehensive career intelligence, AI-guided skill enhancement, and structured placement readiness programs designed for the modern tech industry.
            </p>
            <div className="space-y-4 pt-2">
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 rounded-full bg-[#EAF7F3] text-[#087F73] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</div>
                <div>
                  <h4 className="font-bold text-sm text-[#1F2421]">Offline & Online Institutional Workshops</h4>
                  <p className="text-xs text-[#626A65]">Comprehensive hands-on training sessions delivered to universities covering advanced algorithms and system design.</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-6 h-6 rounded-full bg-[#EAF7F3] text-[#087F73] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">✓</div>
                <div>
                  <h4 className="font-bold text-sm text-[#1F2421]">Real-Time Placement Cell Synchronization</h4>
                  <p className="text-xs text-[#626A65]">Automated tracking of student applications, shortlists, interview rounds, and offer letters in one unified dashboard.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-6">
            <div className="relative mx-auto max-w-lg bg-[#F7F6F2] rounded-3xl p-6 border border-[#E7E4DC] shadow-sm">
              <div className="aspect-video bg-gradient-to-br from-[#087F73]/10 to-[#4F7CAC]/10 rounded-2xl flex items-center justify-center border border-[#E7E4DC] overflow-hidden relative">
                <div className="absolute inset-0 bg-cover bg-center opacity-80" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80')` }} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent flex items-end p-6">
                  <div className="text-white">
                    <p className="text-xs font-semibold uppercase tracking-wider text-[#D99A24]">Live Placement Training</p>
                    <h3 className="font-bold text-lg">Engineering Students Batch of 2026</h3>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Curriculum & Programs Section */}
      <section id="curriculum" className="py-24 px-6 bg-[#F7F6F2]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
            <h2 className="text-xs font-bold tracking-widest text-[#087F73] uppercase">Targeted Learning</h2>
            <h3 className="text-3xl font-extrabold text-[#1F2421] tracking-tight">Build a Better Future with the Right Skills</h3>
            <p className="text-[#626A65] text-sm">Gain the in-demand tech competencies you need to enter top product companies, switch domains, or climb the engineering ladder.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {[
              { id: "fullstack", label: "Full Stack Development" },
              { id: "ai", label: "Data Science & AI" },
              { id: "cloud", label: "Cloud & DevOps" },
              { id: "core", label: "Core Engineering" }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-5 py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer shadow-xs ${
                  activeTab === tab.id
                    ? "bg-[#087F73] text-white shadow-md"
                    : "bg-white text-[#626A65] border border-[#E7E4DC] hover:bg-white/80"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {categoryModules[activeTab].map((mod, idx) => (
              <Card key={idx} leftAccent={idx === 0 ? "teal" : "amber"} className="flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Badge variant={mod.badge === "Critical" || mod.badge === "Advanced" ? "red" : "teal"}>{mod.badge}</Badge>
                    <span className="text-xs font-semibold text-[#8A918C]">{mod.duration}</span>
                  </div>
                  <h4 className="font-bold text-lg text-[#1F2421]">{mod.title}</h4>
                  <p className="text-xs text-[#626A65] leading-relaxed">{mod.desc}</p>
                </div>
                <div className="pt-4 border-t border-[#E7E4DC] flex items-center justify-between">
                  <span className="text-xs font-medium text-[#555D58]">Level: <strong className="text-[#1F2421]">{mod.level}</strong></span>
                  <Link to="/dashboard">
                    <Button variant="outline" size="sm">
                      Start Learning →
                    </Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Comprehensive Features Section */}
      <section id="features" className="py-24 px-6 bg-white border-t border-[#E7E4DC]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold tracking-widest text-[#087F73] uppercase mb-3">Core Capabilities</h2>
            <h3 className="text-3xl font-extrabold text-[#1F2421] tracking-tight">Everything You Need to Ace Placements</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Compass, title: "AI Career Recommendations", desc: "Discover high-paying career paths matched to your exact tech stack, academics, and projects." },
              { icon: Cpu, title: "Skill Gap Analysis", desc: "Pinpoint missing technical competencies and get direct recommendations on what to learn next." },
              { icon: Map, title: "Personalized Roadmap", desc: "Step-by-step interactive milestones guiding you from fundamentals to interview readiness." },
              { icon: Briefcase, title: "Jobs & Internships", desc: "Explore curated placement opportunities and internships with instant company match scores." },
              { icon: MessageSquareCode, title: "AI Career Assistant", desc: "Chat with your 24/7 AI mentor for resume reviews, coding tips, and interview preparation." },
              { icon: TrendingUp, title: "Placement Readiness", desc: "Track your holistic readiness score and academic progress with professional Recharts analytics." }
            ].map((f, i) => {
              const Icon = f.icon;
              return (
                <Card key={i} leftAccent="teal" hoverable className="p-8 space-y-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#EAF7F3] text-[#087F73] flex items-center justify-center border border-[#087F73]/20">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-[#1F2421]">{f.title}</h4>
                  <p className="text-sm text-[#626A65] leading-relaxed">{f.desc}</p>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20 px-6 bg-[#087F73] text-white text-center">
        <div className="max-w-4xl mx-auto space-y-6">
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight">Ready to Accelerate Your Placement Journey?</h2>
          <p className="text-[#EAF7F3] text-base max-w-xl mx-auto">
            Join thousands of engineering students mastering their placement readiness with AI career intelligence.
          </p>
          <Link to="/dashboard" className="inline-block">
            <Button variant="secondary" size="lg" className="bg-white text-[#087F73] hover:bg-[#F7F6F2] shadow-md border-0 font-bold">
              Enter Student Dashboard <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1F2421] text-[#8A918C] py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 text-xs">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-lg bg-[#087F73] flex items-center justify-center text-white">
              <Sparkles className="w-4 h-4" />
            </div>
            <span className="font-bold text-white text-sm">CareerAI</span>
          </div>
          <p>© 2026 AI Placement & Career Agent. All rights reserved.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Support</a>
          </div>
        </div>
      </footer>

      {/* Cute Robot AI Chat Bot Floating Widget */}
      <div className="fixed bottom-6 right-6 z-50">
        {!isChatOpen && (
          <button
            onClick={() => setIsChatOpen(true)}
            className="group flex items-center space-x-3 bg-[#087F73] hover:bg-[#06655c] text-white px-5 py-3.5 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 cursor-pointer border-2 border-white/20"
          >
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center relative">
              <Bot className="w-5 h-5 animate-bounce" />
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-[#087F73]" />
            </div>
            <div className="text-left">
              <p className="text-xs font-bold leading-tight">Chat with CareerBot</p>
              <p className="text-[10px] text-[#EAF7F3]">Ask AI anything!</p>
            </div>
          </button>
        )}

        {isChatOpen && (
          <div className="bg-white rounded-3xl shadow-2xl border border-[#E7E4DC] w-80 sm:w-96 overflow-hidden flex flex-col animate-fade-in">
            {/* Header */}
            <div className="bg-[#087F73] text-white p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center border border-white/30">
                  <Bot className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-sm tracking-tight flex items-center">
                    CareerBot AI <span className="ml-2 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </h3>
                  <p className="text-[10px] text-[#EAF7F3]">Always here to help you get hired</p>
                </div>
              </div>
              <button
                onClick={() => setIsChatOpen(false)}
                className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center text-white/80 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="p-4 h-80 overflow-y-auto no-scrollbar space-y-3 bg-[#F7F6F2]/50">
              {chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed ${
                      msg.sender === "user"
                        ? "bg-[#087F73] text-white rounded-br-sm shadow-xs"
                        : "bg-white text-[#1F2421] rounded-bl-sm border border-[#E7E4DC] shadow-xs"
                    }`}
                  >
                    {msg.sender === "bot" && (
                      <p className="text-[10px] font-bold text-[#087F73] mb-1 flex items-center">
                        <Bot className="w-3 h-3 mr-1" /> CareerBot
                      </p>
                    )}
                    {msg.text}
                  </div>
                </div>
              ))}
            </div>

            {/* Quick Suggestions */}
            <div className="px-3 py-2 bg-white border-t border-[#E7E4DC] flex gap-1.5 overflow-x-auto no-scrollbar text-[11px]">
              <button
                onClick={() => setInputMessage("Check my CGPA readiness")}
                className="px-2.5 py-1 rounded-full bg-[#EAF7F3] text-[#087F73] font-semibold whitespace-nowrap hover:bg-[#087F73] hover:text-white transition-colors cursor-pointer"
              >
                📊 CGPA Readiness
              </button>
              <button
                onClick={() => setInputMessage("Recommend career paths")}
                className="px-2.5 py-1 rounded-full bg-[#FFF6DF] text-[#B87A14] font-semibold whitespace-nowrap hover:bg-[#D99A24] hover:text-white transition-colors cursor-pointer"
              >
                🚀 Career Paths
              </button>
            </div>

            {/* Input Form */}
            <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-[#E7E4DC] flex items-center space-x-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder="Ask CareerBot a question..."
                className="flex-1 px-4 py-2 bg-[#F7F6F2] border border-[#E7E4DC] rounded-xl text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
              />
              <button
                type="submit"
                className="w-9 h-9 rounded-xl bg-[#087F73] hover:bg-[#06655c] text-white flex items-center justify-center transition-colors cursor-pointer shadow-xs shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
