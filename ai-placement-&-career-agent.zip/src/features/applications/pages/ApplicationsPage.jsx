import React, { useState, useEffect } from "react";
import { FileText, CheckCircle2, Clock, XCircle, Award, Building2 } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Badge } from "../../../components/common/Badge";
import { StatCard } from "../../../components/common/StatCard";
import { LoadingState } from "../../../components/common/LoadingState";
import { getApplications } from "../../../services/jobsApi";

export const ApplicationsPage = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("All");

  useEffect(() => {
    getApplications().then((res) => {
      setApplications(res);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <LoadingState message="Loading your placement applications..." />;
  }

  const filtered = statusFilter === "All"
    ? applications
    : applications.filter(a => a.status.toLowerCase() === statusFilter.toLowerCase());

  const appliedCount = applications.length;
  const interviewCount = applications.filter(a => a.status === "Interview").length;
  const offerCount = applications.filter(a => a.status === "Selected").length;
  const assessmentCount = applications.filter(a => a.status === "Assessment").length;

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Application Tracker"
        subtitle="Monitor the real-time status of your job and internship applications across companies."
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <StatCard title="Total Applied" value={appliedCount} icon={FileText} color="blue" />
        <StatCard title="Assessments" value={assessmentCount} icon={Clock} color="amber" />
        <StatCard title="Interviews" value={interviewCount} icon={Building2} color="purple" />
        <StatCard title="Offers Received" value={offerCount} icon={Award} color="green" />
      </div>

      {/* Status Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {["All", "Applied", "Assessment", "Interview", "Selected"].map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              statusFilter === st
                ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
            }`}
          >
            {st}
          </button>
        ))}
      </div>

      {/* Applications Table / Cards */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-gray-50 text-gray-500 uppercase font-semibold">
              <tr>
                <th className="px-4 py-3">Role & Company</th>
                <th className="px-4 py-3">Location & Stipend</th>
                <th className="px-4 py-3">Applied Date</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Timeline Milestone</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map((app) => (
                <tr key={app.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-4 py-3">
                    <p className="font-bold text-gray-900">{app.role}</p>
                    <p className="text-[10px] text-gray-500">{app.company}</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-gray-800">{app.location}</p>
                    <p className="text-[10px] text-gray-500">{app.stipend}</p>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{app.appliedDate}</td>
                  <td className="px-4 py-3">
                    <Badge variant={
                      app.status === "Selected" ? "green" :
                      app.status === "Interview" ? "purple" :
                      app.status === "Assessment" ? "amber" : "blue"
                    }>
                      {app.status}
                    </Badge>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-1">
                      {app.timeline.map((step, sIdx) => (
                        <div key={sIdx} className="flex items-center space-x-1" title={`${step.stage} (${step.date})`}>
                          <div className={`w-3 h-3 rounded-full ${
                            step.completed ? "bg-emerald-500" : "bg-gray-200"
                          } ${step.current ? "ring-2 ring-blue-400" : ""}`} />
                          {sIdx < app.timeline.length - 1 && <div className="w-3 h-0.5 bg-gray-200" />}
                        </div>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
