import React, { useState, useEffect } from "react";
import { Cpu, CheckCircle2, AlertTriangle, Plus, Sparkles } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { ProgressBar } from "../../../components/common/ProgressBar";
import { LoadingState } from "../../../components/common/LoadingState";
import { getSkills } from "../../../services/skillsApi";

export const SkillsPage = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState("All");

  useEffect(() => {
    getSkills().then((res) => {
      setData(res);
      setLoading(false);
    });
  }, []);

  if (loading) {
    return <LoadingState message="Analyzing skill gaps and proficiency..." />;
  }

  const { skills, skillGaps, overallScore } = data;

  const categories = ["All", "Programming", "Web Development", "Database", "Cloud", "Data Structures", "Soft Skills"];

  const filteredSkills = activeCategory === "All"
    ? skills
    : skills.filter(s => s.category === activeCategory);

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Skill Gap Analysis"
        subtitle="Detailed analysis of your technical competencies compared against top industry standards."
      />

      {/* Top Overall Score Banner */}
      <Card className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <div className="inline-flex items-center px-3 py-1 rounded-full bg-white/10 text-blue-100 text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5 mr-1.5" /> AI Skill Assessment
          </div>
          <h2 className="text-2xl font-black">Overall Skill Score: {overallScore}%</h2>
          <p className="text-xs text-blue-100 max-w-lg">
            Your programming and frontend web development skills exceed industry expectations. Focus on backend microservices and system design to unlock top-tier packages.
          </p>
        </div>
        <div className="bg-white/10 border border-white/20 rounded-2xl p-6 text-center backdrop-blur-md min-w-[180px]">
          <p className="text-xs font-bold text-blue-100 uppercase">Skill Gaps Identified</p>
          <p className="text-3xl font-black text-white mt-1">{skillGaps.length} Critical</p>
        </div>
      </Card>

      {/* Categories Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeCategory === cat
                ? "bg-blue-600 text-white shadow-md shadow-blue-500/20"
                : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Skill Comparison List */}
      <Card>
        <h3 className="text-base font-bold text-gray-900 mb-6">Skill Level vs Industry Benchmark</h3>
        <div className="space-y-6">
          {filteredSkills.map((skill, idx) => (
            <div key={idx} className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-gray-900">{skill.name}</span>
                  <Badge variant={skill.priority === "Critical" ? "red" : skill.priority === "Important" ? "amber" : "green"} size="sm">
                    {skill.priority}
                  </Badge>
                </div>
                <span className="text-gray-500">Your Level: <strong className="text-gray-900">{skill.level}%</strong> | Industry: <strong className="text-gray-900">{skill.industryReq}%</strong></span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                    <span>Your Proficiency</span>
                    <span>{skill.level}%</span>
                  </div>
                  <ProgressBar progress={skill.level} color={skill.level >= 80 ? "green" : skill.level >= 60 ? "blue" : "amber"} />
                </div>
                <div>
                  <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                    <span>Industry Requirement</span>
                    <span>{skill.industryReq}%</span>
                  </div>
                  <ProgressBar progress={skill.industryReq} color="purple" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Skill Gaps & Recommended Learning */}
      <div className="space-y-4">
        <h3 className="text-lg font-bold text-[#1F2421]">Recommended Learning for Skill Gaps</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {skillGaps.map((gap, idx) => (
            <Card
              key={idx}
              leftAccent={gap.priority === "Critical" ? "rose" : "amber"}
              className="flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-base text-[#1F2421]">{gap.skill}</h4>
                  <Badge variant={gap.priority === "Critical" ? "red" : "amber"}>{gap.priority}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-[#626A65] bg-[#F7F6F2] p-3 rounded-xl border border-[#E7E4DC]">
                  <div>Current: <strong className="text-[#1F2421]">{gap.currentLevel}%</strong></div>
                  <div>Required: <strong className="text-[#1F2421]">{gap.requiredLevel}%</strong></div>
                  <div>Est. Time: <strong className="text-[#1F2421]">{gap.estimatedTime}</strong></div>
                  <div>Category: <strong className="text-[#1F2421]">{gap.category}</strong></div>
                </div>
                <p className="text-xs text-[#626A65]">
                  <strong className="text-[#1F2421]">Recommended Resource:</strong> {gap.recommendedResource}
                </p>
              </div>
              <Button variant="primary" size="sm" icon={Plus}>
                Add to Roadmap
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};
