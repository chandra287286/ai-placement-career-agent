import React, { useState } from "react";
import { Bell, CheckCircle2, Briefcase, Map, Sparkles, Calendar } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { notificationsList } from "../../../data/data";

export const NotificationsPage = () => {
  const [notifications, setNotifications] = useState(notificationsList);
  const [filter, setFilter] = useState("all");

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const filtered = filter === "unread"
    ? notifications.filter(n => !n.read)
    : notifications;

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Notifications & Alerts"
        subtitle="Stay updated with new job matches, roadmap milestones, and AI recommendations."
        action={
          <Button variant="secondary" size="sm" onClick={markAllRead}>
            Mark All as Read
          </Button>
        }
      />

      <div className="flex gap-2">
        {["all", "unread"].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold capitalize transition-all ${
              filter === f ? "bg-blue-600 text-white shadow-md shadow-blue-500/20" : "bg-white border border-gray-200 text-gray-700"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="space-y-4 max-w-4xl">
        {filtered.length === 0 ? (
          <Card className="text-center py-12">
            <p className="text-xs text-gray-500">No notifications found.</p>
          </Card>
        ) : (
          filtered.map((n) => (
            <Card key={n.id} className={`flex items-start justify-between gap-4 transition-all ${!n.read ? "bg-blue-50/30 border-blue-100" : ""}`}>
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl shrink-0 mt-0.5">
                  <Bell className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h4 className="text-sm font-bold text-gray-900">{n.title}</h4>
                    {!n.read && <span className="w-2 h-2 rounded-full bg-blue-600" />}
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">{n.description}</p>
                  <p className="text-[10px] text-gray-400 pt-1">{n.time}</p>
                </div>
              </div>
              <Badge variant={n.type === "job" ? "blue" : n.type === "roadmap" ? "green" : "purple"}>
                {n.type}
              </Badge>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
