import React, { useState, useEffect } from "react";
import { User, Mail, Phone, MapPin, GraduationCap, Award, FileText, ExternalLink, Edit3, CheckCircle, Plus } from "lucide-react";
import { PageHeader } from "../../../components/common/PageHeader";
import { Card } from "../../../components/common/Card";
import { Button } from "../../../components/common/Button";
import { Badge } from "../../../components/common/Badge";
import { Modal } from "../../../components/common/Modal";
import { LoadingState } from "../../../components/common/LoadingState";
import { ProgressChart } from "../../../components/charts/ProgressChart";
import { getStudentProfile, updateStudentProfile } from "../../../services/profileApi";
import { useAuth } from "../../../context/AuthContext";

export const ProfilePage = () => {
  const { user, updateProfile } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    branch: "",
    year: "",
    cgpa: "",
    college: "",
    location: ""
  });

  useEffect(() => {
    getStudentProfile().then((res) => {
      setData(res);
      setFormData({
        name: res.profile.name,
        email: res.profile.email,
        phone: res.profile.phone,
        branch: res.profile.branch,
        year: res.profile.year,
        cgpa: res.profile.cgpa,
        college: res.profile.college,
        location: res.profile.location
      });
      setLoading(false);
    });
  }, []);

  const handleSave = (e) => {
    e.preventDefault();
    updateStudentProfile(formData);
    updateProfile(formData);
    setEditModalOpen(false);
  };

  if (loading) {
    return <LoadingState message="Loading student profile..." />;
  }

  const { profile, academicPerformance, skills, projects, certifications, achievements } = data;

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        title="Student Profile"
        subtitle="Manage your academic credentials, technical skills, projects, and resume."
        action={
          <Button variant="primary" onClick={() => setEditModalOpen(true)} icon={Edit3}>
            Edit Profile
          </Button>
        }
      />

      {/* Profile Header Card */}
      <Card className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-bl from-blue-100 to-indigo-50 rounded-bl-full -z-10 opacity-70" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center space-x-5">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-extrabold text-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              {profile.name.split(" ").map(n => n[0]).join("")}
            </div>
            <div>
              <div className="flex items-center space-x-3">
                <h2 className="text-xl font-black text-gray-900">{profile.name}</h2>
                <Badge variant="blue">{profile.year}</Badge>
              </div>
              <p className="text-xs font-semibold text-gray-600 mt-1">{profile.branch} · {profile.college}</p>
              <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-gray-500">
                <span className="flex items-center"><MapPin className="w-3.5 h-3.5 mr-1 text-gray-400" /> {profile.location}</span>
                <span className="flex items-center"><Mail className="w-3.5 h-3.5 mr-1 text-gray-400" /> {profile.email}</span>
                <span className="flex items-center"><Phone className="w-3.5 h-3.5 mr-1 text-gray-400" /> {profile.phone}</span>
              </div>
            </div>
          </div>
          <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 text-center min-w-[160px]">
            <p className="text-xs font-bold text-blue-900 uppercase">Profile Completion</p>
            <p className="text-2xl font-black text-blue-600 mt-1">{profile.profileCompletion}%</p>
            <div className="w-full bg-blue-200/60 h-1.5 rounded-full mt-2 overflow-hidden">
              <div className="bg-blue-600 h-full rounded-full" style={{ width: `${profile.profileCompletion}%` }} />
            </div>
          </div>
        </div>
      </Card>

      {/* Academic Information & CGPA Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <Card className="lg:col-span-5 space-y-4">
          <h3 className="text-base font-bold text-gray-900">Academic Information</h3>
          <div className="space-y-3 divide-y divide-gray-50 text-xs">
            <div className="flex justify-between pt-2">
              <span className="text-gray-500 font-medium">Cumulative CGPA</span>
              <span className="font-bold text-gray-900">{profile.cgpa} / 10.0</span>
            </div>
            <div className="flex justify-between pt-3">
              <span className="text-gray-500 font-medium">Current Semester</span>
              <span className="font-bold text-gray-900">{profile.semester}</span>
            </div>
            <div className="flex justify-between pt-3">
              <span className="text-gray-500 font-medium">Active Backlogs</span>
              <span className="font-bold text-emerald-600">{profile.backlogs} (Clean Record)</span>
            </div>
            <div className="flex justify-between pt-3">
              <span className="text-gray-500 font-medium">College Location</span>
              <span className="font-bold text-gray-900">{profile.location}</span>
            </div>
          </div>
        </Card>

        <Card className="lg:col-span-7">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold text-gray-900">Academic Performance Trend</h3>
            <span className="text-xs text-gray-500">CGPA by Semester</span>
          </div>
          <ProgressChart />
        </Card>
      </div>

      {/* Skills Section */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-gray-900">Verified Technical Skills</h3>
          <span className="text-xs text-gray-500">{skills.length} Skills Listed</span>
        </div>
        <div className="flex flex-wrap gap-2.5">
          {skills.map((s, i) => (
            <div key={i} className="flex items-center space-x-2 px-3 py-2 bg-gray-50 border border-gray-100 rounded-xl">
              <span className="text-xs font-semibold text-gray-900">{s.name}</span>
              <Badge variant={s.level >= 80 ? "green" : s.level >= 60 ? "blue" : "amber"} size="sm">
                {s.level}%
              </Badge>
            </div>
          ))}
        </div>
      </Card>

      {/* Projects Section */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-gray-900">Featured Projects</h3>
          <Button variant="secondary" size="sm" icon={Plus}>Add Project</Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {projects.map((proj) => (
            <div key={proj.id} className="p-5 rounded-2xl border border-gray-100 bg-gray-50/50 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm text-gray-900">{proj.name}</h4>
                  <Badge variant="indigo" size="sm">{proj.role}</Badge>
                </div>
                <p className="text-xs text-gray-600 leading-relaxed">{proj.description}</p>
              </div>
              <div className="space-y-3">
                <div className="flex flex-wrap gap-1.5">
                  {proj.technologies.map((t, idx) => (
                    <span key={idx} className="text-[10px] font-medium px-2 py-0.5 bg-white border border-gray-200 rounded-md text-gray-600">
                      {t}
                    </span>
                  ))}
                </div>
                <div className="flex items-center space-x-3 pt-2 border-t border-gray-200/60">
                  <a href={proj.github} target="_blank" rel="noreferrer" className="text-xs font-semibold text-blue-600 hover:underline flex items-center">
                    GitHub <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                  <a href={proj.demo} target="_blank" rel="noreferrer" className="text-xs font-semibold text-gray-700 hover:underline flex items-center">
                    Live Demo <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Certifications & Achievements */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-base font-bold text-gray-900 mb-4">Certifications</h3>
          <div className="space-y-3">
            {certifications.map((cert) => (
              <div key={cert.id} className="p-3.5 rounded-xl border border-gray-100 flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-bold text-gray-900">{cert.title}</h4>
                  <p className="text-[10px] text-gray-500">{cert.issuer} · {cert.date}</p>
                </div>
                <Badge variant="blue" size="sm">Verified</Badge>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <h3 className="text-base font-bold text-gray-900 mb-4">Key Achievements</h3>
          <div className="space-y-3">
            {achievements.map((ach) => (
              <div key={ach.id} className="p-3.5 rounded-xl border border-gray-100 flex items-start space-x-3">
                <Award className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs font-bold text-gray-900">{ach.title}</h4>
                  <p className="text-[10px] text-gray-600 mt-0.5">{ach.description}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Resume Section */}
      <Card className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-gray-900">{profile.resumeFileName}</h4>
            <p className="text-xs text-emerald-600 flex items-center mt-0.5">
              <CheckCircle className="w-3.5 h-3.5 mr-1" /> Uploaded & Parsed successfully (Score: 82%)
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="secondary" size="sm">View Resume</Button>
          <Button variant="primary" size="sm">Update Resume</Button>
        </div>
      </Card>

      {/* Edit Profile Modal */}
      <Modal isOpen={editModalOpen} onClose={() => setEditModalOpen(false)} title="Edit Student Profile">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Phone</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Branch</label>
              <input
                type="text"
                value={formData.branch}
                onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Year</label>
              <input
                type="text"
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">CGPA</label>
              <input
                type="number"
                step="0.1"
                value={formData.cgpa}
                onChange={(e) => setFormData({ ...formData, cgpa: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">College</label>
              <input
                type="text"
                value={formData.college}
                onChange={(e) => setFormData({ ...formData, college: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Location</label>
              <input
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <div className="flex justify-end space-x-3 pt-4 border-t border-gray-100">
            <Button variant="secondary" onClick={() => setEditModalOpen(false)}>Cancel</Button>
            <Button variant="primary" type="submit">Save Changes</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
