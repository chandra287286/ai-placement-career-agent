import api from "./api";
import { dashboardStats, careerRecommendations, skillGaps, careerRoadmap, jobsList, initialChatMessages } from "../data/data";

export const getDashboard = async () => {
  try {
    const response = await api.get("/dashboard");
    return response.data;
  } catch (error) {
    // Fallback to central mock data when backend is not connected
    return {
      stats: dashboardStats,
      recommendedCareer: careerRecommendations[0],
      skillGaps: skillGaps,
      roadmapProgress: careerRoadmap,
      recommendedOpportunities: jobsList.slice(0, 3)
    };
  }
};
