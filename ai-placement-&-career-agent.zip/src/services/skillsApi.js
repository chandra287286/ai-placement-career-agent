import api from "./api";
import { studentSkills, skillGaps } from "../data/data";

export const getSkills = async () => {
  try {
    const response = await api.get("/skills");
    return response.data;
  } catch (error) {
    return {
      skills: studentSkills,
      skillGaps: skillGaps,
      overallScore: 72
    };
  }
};
