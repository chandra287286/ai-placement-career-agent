import api from "./api";
import { jobsList, internshipsList, applicationsList } from "../data/data";

export const getJobs = async () => {
  try {
    const response = await api.get("/jobs");
    return response.data;
  } catch (error) {
    return jobsList;
  }
};

export const getInternships = async () => {
  try {
    const response = await api.get("/internships");
    return response.data;
  } catch (error) {
    return internshipsList;
  }
};

export const getApplications = async () => {
  try {
    const response = await api.get("/applications");
    return response.data;
  } catch (error) {
    return applicationsList;
  }
};

export const applyToOpportunity = async (opportunityId) => {
  try {
    const response = await api.post("/applications", { opportunityId });
    return response.data;
  } catch (error) {
    return { success: true, message: "Application submitted successfully" };
  }
};
