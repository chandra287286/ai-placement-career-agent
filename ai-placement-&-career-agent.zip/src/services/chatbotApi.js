import api from "./api";

export const sendMessage = async (messageText) => {
  try {
    const response = await api.post("/chat", { message: messageText });
    return response.data;
  } catch (error) {
    // Intelligent fallback responses based on user prompt keywords
    const lower = messageText.toLowerCase();
    let reply = "That's a great question about your career development! As your AI Placement Agent, I recommend keeping your roadmap updated and practicing LeetCode daily.";
    
    if (lower.includes("career") || lower.includes("best") || lower.includes("role")) {
      reply = "Based on your 90% proficiency in React and 8.4 CGPA, **Full Stack Developer** (92% match) and **Frontend Engineer** (90% match) are your strongest career paths. You can explore them in the Career Recommendations tab.";
    } else if (lower.includes("skill") || lower.includes("gap") || lower.includes("node") || lower.includes("system design")) {
      reply = "Your primary skill gaps are **Node.js & Express** and **System Design**. I recommend allocating 4-5 hours this week to complete Phase 3 of your career roadmap and reviewing our recommended resources.";
    } else if (lower.includes("roadmap") || lower.includes("full stack")) {
      reply = "Your Full Stack career roadmap has 5 phases. You have successfully completed Foundation and Frontend! You are currently 65% through Backend Development. Keep up the great momentum!";
    } else if (lower.includes("internship") || lower.includes("job") || lower.includes("opportunity")) {
      reply = "We currently have 4 top matching opportunities for you, including a Frontend Developer Intern role at InnoVibe Technologies (94% match, ₹35K/mo stipend) and a Full Stack role at TechNova Solutions.";
    } else if (lower.includes("resume") || lower.includes("cv")) {
      reply = "Your resume `Arjun_Reddy_Resume_2026.pdf` is uploaded and scores 82%. To boost it further, highlight your AI Code Review Assistant project and add metrics (e.g. 'improved API response by 30%').";
    }

    return {
      reply,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  }
};
