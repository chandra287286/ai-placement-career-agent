import api from "./api";
import { studentProfile, academicPerformance, studentSkills, projectsList, certificationsList, achievementsList } from "../data/data";

export const getStudentProfile = async () => {
  try {
    const response = await api.get("/profile");
    return response.data;
  } catch (error) {
    return {
      profile: studentProfile,
      academicPerformance: academicPerformance,
      skills: studentSkills,
      projects: projectsList,
      certifications: certificationsList,
      achievements: achievementsList
    };
  }
};

export const updateStudentProfile = async (profileData) => {
  try {
    const response = await api.put("/profile", profileData);
    return response.data;
  } catch (error) {
    // Mock success fallback
    return { success: true, profile: { ...studentProfile, ...profileData } };
  }
};
