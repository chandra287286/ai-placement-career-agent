import api from "./api";
import { careerRoadmap } from "../data/data";

export const getRoadmap = async () => {
  try {
    const response = await api.get("/roadmap");
    return response.data;
  } catch (error) {
    return careerRoadmap;
  }
};

export const updateTaskStatus = async (phaseId, taskId, completed) => {
  try {
    const response = await api.patch(`/roadmap/phase/${phaseId}/task/${taskId}`, { completed });
    return response.data;
  } catch (error) {
    return { success: true, phaseId, taskId, completed };
  }
};
