import api from "./api";
import { careerRecommendations } from "../data/data";

export const getCareerRecommendations = async () => {
  try {
    const response = await api.get("/career/recommendations");
    return response.data;
  } catch (error) {
    return careerRecommendations;
  }
};
