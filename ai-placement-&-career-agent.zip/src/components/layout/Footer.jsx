import React from "react";

export const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-100 py-6 px-6 text-center text-xs text-gray-500">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <p>© 2026 AI Placement & Career Agent. All rights reserved.</p>
        <div className="flex space-x-6">
          <a href="#" className="hover:text-blue-600 transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-blue-600 transition-colors">Support</a>
        </div>
      </div>
    </footer>
  );
};
