import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  User,
  Compass,
  Cpu,
  Map,
  Briefcase,
  GraduationCap,
  FileText,
  MessageSquareCode,
  Bell,
  Settings,
  LogOut,
  Sparkles
} from "lucide-react";
import { Avatar } from "../common/Avatar";
import { useAuth } from "../../context/AuthContext";

export const Sidebar = ({ isOpen, onCloseMobile }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const navGroups = [
    {
      title: "Overview",
      items: [
        { label: "Dashboard", path: "/dashboard", icon: LayoutDashboard }
      ]
    },
    {
      title: "Career Journey",
      items: [
        { label: "Recommendations", path: "/career", icon: Compass },
        { label: "Skill Gap", path: "/skills", icon: Cpu },
        { label: "Career Roadmap", path: "/roadmap", icon: Map }
      ]
    },
    {
      title: "Opportunities",
      items: [
        { label: "Jobs", path: "/jobs", icon: Briefcase },
        { label: "Internships", path: "/internships", icon: GraduationCap },
        { label: "Applications", path: "/applications", icon: FileText }
      ]
    },
    {
      title: "Tools",
      items: [
        { label: "AI Assistant", path: "/assistant", icon: MessageSquareCode },
        { label: "Student Profile", path: "/profile", icon: User }
      ]
    },
    {
      title: "Other",
      items: [
        { label: "Notifications", path: "/notifications", icon: Bell },
        { label: "Settings", path: "/settings", icon: Settings }
      ]
    }
  ];

  const sidebarContent = (
    <div className="flex flex-col h-full bg-white border-r border-[#E7E4DC] py-6">
      {/* Navigation Links */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 space-y-4 pt-4">
        {navGroups.map((group, idx) => (
          <div key={idx}>
            <p className="px-4 py-2 text-[10px] font-bold text-[#8A918C] uppercase tracking-widest">
              {group.title}
            </p>
            <div className="space-y-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={onCloseMobile}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-4 py-2.5 rounded-[10px] font-medium text-sm transition-all ${
                        isActive
                          ? "bg-[#EAF7F3] text-[#087F73] font-semibold shadow-xs"
                          : "text-[#626A65] hover:bg-[#F7F6F2] hover:text-[#1F2421]"
                      }`
                    }
                  >
                    <Icon className="w-5 h-5 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </NavLink>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Upgrade Pro Plan Card */}
      <div className="px-6 mt-auto pt-4">
        <div className="bg-[#087F73] rounded-2xl p-4 text-white shadow-sm">
          <div className="flex items-center justify-between mb-1">
            <p className="text-xs font-semibold uppercase tracking-wider text-[#EAF7F3]">Pro Intelligence</p>
            <span className="px-2 py-0.5 rounded-full bg-[#D99A24] text-white text-[10px] font-bold">PRO</span>
          </div>
          <p className="text-sm font-bold mt-1">Unlock Mock Interviews</p>
          <button
            onClick={() => navigate("/settings")}
            className="w-full bg-white text-[#087F73] text-xs font-bold py-2 rounded-[10px] mt-3 shadow-xs cursor-pointer hover:bg-[#F7F6F2] transition-colors"
          >
            Upgrade Plan
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 fixed inset-y-0 left-0 z-20 pt-16">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-[#1F2421]/50 backdrop-blur-xs transition-opacity"
            onClick={onCloseMobile}
          />
          <div className="fixed inset-y-0 left-0 w-72 bg-white shadow-2xl z-50 animate-slide-right pt-4">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};

