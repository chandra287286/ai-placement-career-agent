import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bell, Search, Menu, X, Sparkles, User, Settings, LogOut, ShieldCheck } from "lucide-react";
import { Avatar } from "../common/Avatar";
import { useAuth } from "../../context/AuthContext";
import { notificationsList } from "../../data/data";

export const Navbar = ({ onMobileMenuToggle }) => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [notifications, setNotifications] = useState(notificationsList);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const searchItems = [
    { title: "Full Stack Software Engineer", category: "Career", path: "/career", desc: "React, Node.js, PostgreSQL architecture" },
    { title: "Cloud & DevOps Specialist", category: "Career", path: "/career", desc: "AWS, Docker, Kubernetes pipelines" },
    { title: "AI/ML Integration Engineer", category: "Career", path: "/career", desc: "Gemini API, Python, PyTorch" },
    { title: "React & TypeScript", category: "Skill", path: "/skills", desc: "Frontend component architecture" },
    { title: "PostgreSQL & Database Design", category: "Skill", path: "/skills", desc: "Relational modeling and indexing" },
    { title: "Career Roadmap: Phase 1 to 4", category: "Roadmap", path: "/roadmap", desc: "Step-by-step milestone tracking" },
    { title: "Software Engineer Intern", category: "Job", path: "/jobs", desc: "96% Match score available" },
    { title: "Frontend Developer", category: "Job", path: "/jobs", desc: "Remote / Hybrid placement" },
    { title: "AI Assistant Mentor", category: "Tool", path: "/assistant", desc: "24/7 AI interview prep and coding help" }
  ];

  const filteredSearchItems = searchQuery.trim() === ""
    ? searchItems.slice(0, 5)
    : searchItems.filter(item =>
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.desc.toLowerCase().includes(searchQuery.toLowerCase())
      );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-[#E7E4DC] h-16 flex items-center justify-between px-6">
      {/* Left: Mobile menu toggle & Brand */}
      <div className="flex items-center space-x-3">
        <button
          onClick={onMobileMenuToggle}
          className="lg:hidden p-2 text-[#626A65] hover:text-[#1F2421] rounded-lg hover:bg-[#F7F6F2]"
        >
          <Menu className="w-5 h-5" />
        </button>
        <Link to="/dashboard" className="hidden lg:flex items-center space-x-2.5">
          <div className="w-8 h-8 bg-[#087F73] rounded-lg flex items-center justify-center shadow-xs text-white">
            <Sparkles className="w-4 h-4" />
          </div>
          <span className="font-bold text-lg text-[#1F2421] tracking-tight">
            CareerAI
          </span>
        </Link>
      </div>

      {/* Center: Global Search Bar */}
      <div className="hidden md:flex items-center max-w-md w-full mx-8 relative">
        <div className="relative w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8A918C]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsSearchFocused(true)}
            onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
            placeholder="Search careers, skills, roadmaps..."
            className="w-full pl-10 pr-4 py-1.5 bg-[#F7F6F2] border border-[#E7E4DC] rounded-full text-xs text-[#1F2421] placeholder-[#8A918C] focus:outline-none focus:ring-2 focus:ring-[#087F73] focus:bg-white transition-all"
          />
        </div>

        {isSearchFocused && (
          <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-2xl shadow-xl border border-[#E7E4DC] py-2 z-50 animate-fade-in max-h-96 overflow-y-auto no-scrollbar">
            <div className="px-4 py-2 border-b border-[#E7E4DC] flex items-center justify-between">
              <span className="text-[10px] font-bold text-[#8A918C] uppercase tracking-wider">
                {searchQuery.trim() === "" ? "Suggested & Popular" : "Matching Results"}
              </span>
              <span className="text-[10px] text-[#087F73] font-semibold">{filteredSearchItems.length} found</span>
            </div>
            <div className="divide-y divide-[#E7E4DC]/50">
              {filteredSearchItems.length === 0 ? (
                <div className="px-4 py-6 text-center text-xs text-[#8A918C]">
                  No matching careers, skills, or roadmaps found.
                </div>
              ) : (
                filteredSearchItems.map((item, idx) => (
                  <div
                    key={idx}
                    onMouseDown={() => {
                      navigate(item.path);
                      setSearchQuery("");
                      setIsSearchFocused(false);
                    }}
                    className="px-4 py-2.5 hover:bg-[#F7F6F2] cursor-pointer transition-colors flex items-center justify-between"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-[#1F2421]">{item.title}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-[#EAF7F3] text-[#087F73]">
                          {item.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-[#626A65] mt-0.5">{item.desc}</p>
                    </div>
                    <span className="text-xs text-[#8A918C]">→</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Right: Notifications & Profile */}
      <div className="flex items-center space-x-4">
        {/* Notifications Dropdown */}
        <div className="relative">
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setShowProfileMenu(false);
            }}
            className="relative w-10 h-10 flex items-center justify-center text-slate-500 hover:bg-slate-50 rounded-full cursor-pointer transition-colors"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-white animate-pulse" />
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 z-50 animate-fade-in">
              <div className="flex items-center justify-between px-4 pb-3 border-b border-slate-100">
                <h4 className="font-bold text-sm text-slate-900">Notifications</h4>
                {unreadCount > 0 && (
                  <button
                    onClick={markAllRead}
                    className="text-xs text-indigo-600 hover:underline font-medium"
                  >
                    Mark all as read
                  </button>
                )}
              </div>
              <div className="max-h-80 overflow-y-auto divide-y divide-slate-50">
                {notifications.length === 0 ? (
                  <p className="text-center py-6 text-xs text-slate-500">No notifications</p>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      className={`p-3.5 hover:bg-slate-50 transition-colors cursor-pointer ${
                        !n.read ? "bg-indigo-50/40" : ""
                      }`}
                      onClick={() => navigate("/notifications")}
                    >
                      <div className="flex items-start justify-between">
                        <p className="text-xs font-semibold text-slate-900">{n.title}</p>
                        <span className="text-[10px] text-slate-400">{n.time}</span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 line-clamp-2">{n.description}</p>
                    </div>
                  ))
                )}
              </div>
              <div className="pt-2 px-4 border-t border-slate-100 text-center">
                <button
                  onClick={() => {
                    setShowNotifications(false);
                    navigate("/notifications");
                  }}
                  className="text-xs font-semibold text-indigo-600 hover:text-indigo-700"
                >
                  View All Notifications
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Profile Dropdown */}
        <div className="relative flex items-center gap-3 border-l pl-4 border-slate-200">
          <button
            onClick={() => {
              setShowProfileMenu(!showProfileMenu);
              setShowNotifications(false);
            }}
            className="flex items-center space-x-3 p-1 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="text-right hidden sm:block">
              <p className="text-sm font-semibold leading-none text-slate-900">{user.name}</p>
              <p className="text-[11px] text-slate-500 mt-1">{user.branch}</p>
            </div>
            <div className="w-10 h-10 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center text-indigo-700 font-bold text-xs">
              {user.name.split(" ").map(n => n[0]).join("")}
            </div>
          </button>

          {showProfileMenu && (
            <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-2xl shadow-xl border border-[#E7E4DC] py-2 z-50 animate-fade-in">
              <div className="px-4 py-3 border-b border-[#E7E4DC]">
                <p className="text-sm font-bold text-[#1F2421]">{user.name}</p>
                <p className="text-xs text-[#626A65] truncate">{user.email}</p>
                <div className="mt-2 inline-flex items-center px-2 py-0.5 rounded-md bg-[#EAF7F3] text-[#087F73] text-[10px] font-semibold border border-[#087F73]/20">
                  CGPA: {user.cgpa} • {user.year}
                </div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setShowProfileMenu(false);
                    navigate("/profile");
                  }}
                  className="w-full flex items-center px-4 py-2 text-xs text-[#1F2421] hover:bg-[#F7F6F2] font-medium cursor-pointer"
                >
                  <User className="w-4 h-4 mr-2.5 text-[#8A918C]" />
                  Student Profile
                </button>
                <button
                  onClick={() => {
                    setShowProfileMenu(false);
                    navigate("/settings");
                  }}
                  className="w-full flex items-center px-4 py-2 text-xs text-[#1F2421] hover:bg-[#F7F6F2] font-medium cursor-pointer"
                >
                  <Settings className="w-4 h-4 mr-2.5 text-[#8A918C]" />
                  Account Settings
                </button>
              </div>

              <div className="pt-1 border-t border-[#E7E4DC]">
                <button
                  onClick={() => {
                    setShowProfileMenu(false);
                    logout();
                    navigate("/");
                  }}
                  className="w-full flex items-center px-4 py-2 text-xs text-[#C94B4B] hover:bg-rose-50 font-medium cursor-pointer"
                >
                  <LogOut className="w-4 h-4 mr-2.5" />
                  Sign Out
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
