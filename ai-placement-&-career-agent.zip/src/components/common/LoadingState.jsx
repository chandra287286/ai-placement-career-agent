import React from "react";
import { Loader2 } from "lucide-react";

export const LoadingState = ({ message = "Loading your career intelligence..." }) => {
  return (
    <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
      <Loader2 className="w-10 h-10 text-blue-600 animate-spin mb-4" />
      <p className="text-sm font-medium text-gray-600">{message}</p>
    </div>
  );
};
