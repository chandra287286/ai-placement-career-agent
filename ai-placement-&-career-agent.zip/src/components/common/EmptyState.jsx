import React from "react";
import { FolderSearch } from "lucide-react";

export const EmptyState = ({ title = "No items found", description = "Try adjusting your search or filters to find what you are looking for.", icon: Icon = FolderSearch }) => {
  return (
    <div className="flex flex-col items-center justify-center py-12 px-4 text-center bg-white rounded-2xl border border-gray-100">
      <div className="p-4 bg-blue-50 text-blue-600 rounded-2xl mb-4">
        <Icon className="w-8 h-8" />
      </div>
      <h3 className="text-base font-bold text-gray-900 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 max-w-sm">{description}</p>
    </div>
  );
};
