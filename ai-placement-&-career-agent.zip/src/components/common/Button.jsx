import React from "react";

export const Button = ({
  children,
  variant = "primary",
  size = "md",
  className = "",
  onClick,
  disabled = false,
  type = "button",
  icon: Icon
}) => {
  const baseStyles = "inline-flex items-center justify-center font-medium rounded-[10px] transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer shadow-xs";
  
  const variants = {
    primary: "bg-[#087F73] hover:bg-[#076D63] text-white focus:ring-[#087F73] shadow-sm",
    secondary: "bg-white hover:bg-[#F7F6F2] text-[#303733] border border-[#DCD9D1] focus:ring-[#087F73] shadow-xs",
    outline: "border border-[#087F73] text-[#087F73] hover:bg-[#EAF7F3] focus:ring-[#087F73]",
    danger: "bg-[#C94B4B] hover:bg-[#B44242] text-white focus:ring-[#C94B4B] shadow-xs",
    success: "bg-[#159A72] hover:bg-[#128562] text-white focus:ring-[#159A72] shadow-xs",
    ghost: "bg-transparent hover:bg-[#F7F6F2] text-[#626A65] shadow-none"
  };

  const sizes = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2.5 text-sm",
    lg: "px-6 py-3 text-base"
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${variants[variant] || variants.primary} ${sizes[size]} ${className}`}
    >
      {Icon && <Icon className="w-4 h-4 mr-2 -ml-1 shrink-0" />}
      {children}
    </button>
  );
};

