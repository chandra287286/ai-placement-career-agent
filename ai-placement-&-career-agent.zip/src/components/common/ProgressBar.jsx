import React from "react";

export const ProgressBar = ({ progress = 0, color = "teal", height = "h-2.5", showLabel = false }) => {
  const colorMap = {
    teal: "bg-[#087F73]",
    green: "bg-[#159A72]",
    amber: "bg-[#D99A24]",
    blue: "bg-[#4F7CAC]",
    rose: "bg-[#C94B4B]"
  };

  const clamped = Math.min(Math.max(progress, 0), 100);

  return (
    <div className="w-full">
      {showLabel && (
        <div className="flex justify-between items-center mb-1.5 text-xs font-medium text-[#555D58]">
          <span>Progress</span>
          <span>{clamped}%</span>
        </div>
      )}
      <div className={`w-full bg-[#E7E4DC]/40 rounded-full overflow-hidden ${height}`}>
        <div
          className={`h-full rounded-full transition-all duration-500 ${colorMap[color] || colorMap.teal}`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
};

