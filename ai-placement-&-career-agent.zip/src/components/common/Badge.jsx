import React from "react";

export const Badge = ({ children, variant = "blue", className = "", size = "md" }) => {
  const variants = {
    blue: "bg-[#EEF4FA] text-[#4F7CAC] border border-[#4F7CAC]/20",
    green: "bg-[#EAF8F2] text-[#159A72] border border-[#159A72]/20",
    amber: "bg-[#FFF6DF] text-[#C88719] border border-[#C88719]/20",
    red: "bg-[#FDEEEE] text-[#C94B4B] border border-[#C94B4B]/20",
    teal: "bg-[#EAF7F3] text-[#087F73] border border-[#087F73]/20",
    gray: "bg-[#F7F6F2] text-[#626A65] border border-[#E7E4DC]",
    indigo: "bg-[#EAF7F3] text-[#087F73] border border-[#087F73]/20"
  };

  const sizes = {
    sm: "px-2 py-0.5 text-[11px]",
    md: "px-3 py-1 text-xs"
  };

  return (
    <span className={`inline-flex items-center font-medium rounded-full ${variants[variant] || variants.blue} ${sizes[size]} ${className}`}>
      {children}
    </span>
  );
};

