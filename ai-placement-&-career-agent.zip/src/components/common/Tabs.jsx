import React from "react";

export const Tabs = ({ tabs, activeTab, onChange, className = "" }) => {
  return (
    <div className={`flex space-x-1 bg-gray-100 p-1 rounded-xl ${className}`}>
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onChange(tab.id)}
            className={`flex-1 px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              isActive
                ? "bg-white text-blue-600 shadow-xs"
                : "text-gray-600 hover:text-gray-900 hover:bg-gray-200/60"
            }`}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
};
