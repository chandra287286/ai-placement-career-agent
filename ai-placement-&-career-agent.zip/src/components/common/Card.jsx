import React from "react";

export const Card = ({ children, className = "", onClick, hoverable = false, leftAccent = "teal" }) => {
  const accentColors = {
    teal: "border-l-4 border-l-[#087F73]",
    amber: "border-l-4 border-l-[#D99A24]",
    blue: "border-l-4 border-l-[#4F7CAC]",
    green: "border-l-4 border-l-[#159A72]",
    rose: "border-l-4 border-l-[#C94B4B]",
    orange: "border-l-4 border-l-[#D99A24]"
  };

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-2xl border border-[#E7E4DC] shadow-[0_2px_8px_rgba(30,40,35,0.04)] p-6 transition-all duration-200 overflow-hidden ${
        leftAccent && accentColors[leftAccent] ? accentColors[leftAccent] : accentColors.teal
      } ${
        hoverable ? "hover:shadow-md hover:border-[#087F73]/40 cursor-pointer" : ""
      } ${className}`}
    >
      {children}
    </div>
  );
};


