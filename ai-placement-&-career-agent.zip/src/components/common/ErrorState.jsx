import React from "react";
import { AlertTriangle } from "lucide-react";
import { Button } from "./Button";

export const ErrorState = ({ title = "Something went wrong", message = "Unable to load data at this moment.", onRetry }) => {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center bg-white rounded-2xl border border-rose-100">
      <div className="p-4 bg-rose-50 text-rose-600 rounded-2xl mb-4">
        <AlertTriangle className="w-8 h-8" />
      </div>
      <h3 className="text-base font-bold text-gray-900 mb-1">{title}</h3>
      <p className="text-sm text-gray-500 max-w-sm mb-6">{message}</p>
      {onRetry && (
        <Button onClick={onRetry} variant="secondary">
          Try Again
        </Button>
      )}
    </div>
  );
};
