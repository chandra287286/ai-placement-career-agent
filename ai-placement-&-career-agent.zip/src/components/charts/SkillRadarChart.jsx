import React from "react";
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from "recharts";

const data = [
  { subject: 'Frontend', A: 95, fullMark: 100 },
  { subject: 'Backend', A: 65, fullMark: 100 },
  { subject: 'Database', A: 80, fullMark: 100 },
  { subject: 'Cloud & DevOps', A: 45, fullMark: 100 },
  { subject: 'Data Structures', A: 75, fullMark: 100 },
  { subject: 'Soft Skills', A: 88, fullMark: 100 },
];

export const SkillRadarChart = () => {
  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
          <PolarGrid stroke="#e5e7eb" />
          <PolarAngleAxis dataKey="subject" tick={{ fill: '#4b5563', fontSize: 12 }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} />
          <Radar name="Arjun Reddy" dataKey="A" stroke="#2563eb" fill="#3b82f6" fillOpacity={0.4} />
          <Tooltip />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
};
