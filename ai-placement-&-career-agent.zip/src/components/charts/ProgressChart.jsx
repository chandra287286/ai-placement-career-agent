import React from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { academicPerformance } from "../../data/data";

export const ProgressChart = () => {
  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={academicPerformance} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
          <XAxis dataKey="semester" tick={{ fontSize: 12, fill: '#6b7280' }} />
          <YAxis domain={[0, 10]} tick={{ fontSize: 12, fill: '#6b7280' }} />
          <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e5e7eb' }} />
          <Bar dataKey="cgpa" fill="#3b82f6" radius={[6, 6, 0, 0]} name="Your CGPA" />
          <Bar dataKey="average" fill="#e5e7eb" radius={[6, 6, 0, 0]} name="Class Average" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
