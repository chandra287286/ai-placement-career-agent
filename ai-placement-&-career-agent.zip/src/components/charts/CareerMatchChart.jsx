import React from "react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";
import { careerRecommendations } from "../../data/data";

const data = careerRecommendations.map(c => ({
  name: c.title.replace("Developer", "Dev").replace("Engineer", "Eng"),
  match: c.matchScore
}));

export const CareerMatchChart = () => {
  return (
    <div className="w-full h-72">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 10, right: 10, left: 30, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f3f4f6" />
          <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 12, fill: '#6b7280' }} />
          <YAxis dataKey="name" type="category" tick={{ fontSize: 12, fill: '#4b5563' }} width={100} />
          <Tooltip contentStyle={{ backgroundColor: '#fff', borderRadius: '12px', border: '1px solid #e5e7eb' }} />
          <Bar dataKey="match" fill="#6366f1" radius={[0, 6, 6, 0]} name="Match %" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};
