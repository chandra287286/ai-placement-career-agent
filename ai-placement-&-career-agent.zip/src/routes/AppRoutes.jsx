import React from "react";
import { Routes, Route } from "react-router-dom";
import { Layout } from "../components/layout/Layout";
import { LandingPage } from "../features/landing/pages/LandingPage";
import { LoginPage } from "../features/landing/pages/LoginPage";
import { DashboardPage } from "../features/dashboard/pages/DashboardPage";
import { ProfilePage } from "../features/profile/pages/ProfilePage";
import { CareerPage } from "../features/career/pages/CareerPage";
import { SkillsPage } from "../features/skills/pages/SkillsPage";
import { RoadmapPage } from "../features/roadmap/pages/RoadmapPage";
import { JobsPage } from "../features/jobs/pages/JobsPage";
import { ApplicationsPage } from "../features/applications/pages/ApplicationsPage";
import { ChatbotPage } from "../features/chatbot/pages/ChatbotPage";
import { NotificationsPage } from "../features/notifications/pages/NotificationsPage";
import { SettingsPage } from "../features/settings/pages/SettingsPage";

export const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route element={<Layout />}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/career" element={<CareerPage />} />
        <Route path="/skills" element={<SkillsPage />} />
        <Route path="/roadmap" element={<RoadmapPage />} />
        <Route path="/jobs" element={<JobsPage />} />
        <Route path="/internships" element={<JobsPage />} />
        <Route path="/applications" element={<ApplicationsPage />} />
        <Route path="/assistant" element={<ChatbotPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
      </Route>
    </Routes>
  );
};
