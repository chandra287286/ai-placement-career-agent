export const studentProfile = {
  name: "Arjun Reddy",
  email: "arjun.reddy@example.com",
  phone: "+91 98765 43210",
  branch: "Computer Science Engineering",
  year: "3rd Year",
  semester: "6th Semester",
  cgpa: 8.4,
  college: "ABC Institute of Technology & Science",
  location: "Bengaluru, India",
  profileCompletion: 82,
  backlogs: 0,
  github: "https://github.com/arjunreddy",
  linkedin: "https://linkedin.com/in/arjunreddy",
  portfolio: "https://arjunreddy.dev",
  resumeUploaded: true,
  resumeFileName: "Arjun_Reddy_Resume_2026.pdf",
  bio: "Passionate CS undergrad specializing in full-stack web engineering, distributed systems, and AI-driven applications. Active open-source contributor and hackathon winner."
};

export const academicPerformance = [
  { semester: "Sem 1", cgpa: 8.1, average: 7.5 },
  { semester: "Sem 2", cgpa: 8.3, average: 7.6 },
  { semester: "Sem 3", cgpa: 8.0, average: 7.4 },
  { semester: "Sem 4", cgpa: 8.5, average: 7.7 },
  { semester: "Sem 5", cgpa: 8.8, average: 7.8 }
];

export const studentSkills = [
  { name: "Java", category: "Programming", level: 85, industryReq: 90, priority: "Good", currentLevelBadge: "Intermediate", targetLevel: "Advanced" },
  { name: "Python", category: "Programming", level: 80, industryReq: 85, priority: "Good", currentLevelBadge: "Intermediate", targetLevel: "Advanced" },
  { name: "React.js", category: "Web Development", level: 90, industryReq: 90, priority: "Good", currentLevelBadge: "Advanced", targetLevel: "Advanced" },
  { name: "JavaScript / ES6+", category: "Programming", level: 92, industryReq: 95, priority: "Good", currentLevelBadge: "Advanced", targetLevel: "Advanced" },
  { name: "SQL & Databases", category: "Database", level: 78, industryReq: 85, priority: "Important", currentLevelBadge: "Intermediate", targetLevel: "Advanced" },
  { name: "Git & GitHub", category: "Web Development", level: 85, industryReq: 90, priority: "Good", currentLevelBadge: "Advanced", targetLevel: "Advanced" },
  { name: "Data Structures & Algos", category: "Data Structures", level: 75, industryReq: 90, priority: "Critical", currentLevelBadge: "Intermediate", targetLevel: "Expert" },
  { name: "Node.js & Express", category: "Web Development", level: 60, industryReq: 85, priority: "Critical", currentLevelBadge: "Beginner", targetLevel: "Advanced" },
  { name: "System Design", category: "Architecture", level: 45, industryReq: 80, priority: "Critical", currentLevelBadge: "Beginner", targetLevel: "Intermediate" },
  { name: "AWS & Cloud Basics", category: "Cloud", level: 40, industryReq: 75, priority: "Important", currentLevelBadge: "Beginner", targetLevel: "Intermediate" },
  { name: "Communication & Teamwork", category: "Soft Skills", level: 88, industryReq: 85, priority: "Good", currentLevelBadge: "Advanced", targetLevel: "Advanced" }
];

export const skillGaps = [
  {
    skill: "Node.js & Express",
    currentLevel: 60,
    requiredLevel: 85,
    priority: "Critical",
    estimatedTime: "3 weeks",
    recommendedResource: "Node.js Microservices Masterclass (Coursera / Udemy)",
    category: "Web Development"
  },
  {
    skill: "System Design",
    currentLevel: 45,
    requiredLevel: 80,
    priority: "Critical",
    estimatedTime: "4 weeks",
    recommendedResource: "Designing Data-Intensive Applications & System Design Primer",
    category: "Architecture"
  },
  {
    skill: "AWS & Cloud Basics",
    currentLevel: 40,
    requiredLevel: 75,
    priority: "Important",
    estimatedTime: "2 weeks",
    recommendedResource: "AWS Certified Cloud Practitioner Roadmap",
    category: "Cloud"
  },
  {
    skill: "Advanced Data Structures",
    currentLevel: 75,
    requiredLevel: 90,
    priority: "Important",
    estimatedTime: "3 weeks",
    recommendedResource: "LeetCode Top 150 Interview Preparation",
    category: "Data Structures"
  }
];

export const careerRecommendations = [
  {
    id: "c1",
    title: "Full Stack Developer",
    matchScore: 92,
    salaryRange: "₹12 LPA - ₹24 LPA",
    demand: "Very High",
    description: "Build scalable end-to-end web applications combining robust backend architectures with modern reactive frontend interfaces.",
    skillBreakdown: {
      frontend: 95,
      backend: 65,
      database: 80,
      cloud: 45
    },
    requiredSkills: ["React", "Node.js", "JavaScript", "SQL", "Git", "System Design"],
    missingSkills: ["Node.js", "System Design", "AWS"],
    growthPotential: "Excellent",
    topCompanies: ["Google", "Microsoft", "Zomato", "Swiggy", "Razorpay"]
  },
  {
    id: "c2",
    title: "Frontend Engineer",
    matchScore: 90,
    salaryRange: "₹10 LPA - ₹20 LPA",
    demand: "High",
    description: "Design and implement responsive, high-performance user interfaces with state-of-the-art web technologies and state management.",
    skillBreakdown: {
      frontend: 95,
      backend: 50,
      database: 60,
      cloud: 40
    },
    requiredSkills: ["React", "JavaScript", "CSS/Tailwind", "TypeScript", "Redux", "UI/UX Principles"],
    missingSkills: ["TypeScript", "Advanced State Management"],
    growthPotential: "High",
    topCompanies: ["Flipkart", "Myntra", "Adobe", "PhonePe"]
  },
  {
    id: "c3",
    title: "Software Development Engineer (SDE-1)",
    matchScore: 84,
    salaryRange: "₹14 LPA - ₹30 LPA",
    demand: "Very High",
    description: "Solve complex algorithmic challenges, build distributed backend microservices, and collaborate with cross-functional product teams.",
    skillBreakdown: {
      frontend: 70,
      backend: 75,
      database: 80,
      cloud: 50
    },
    requiredSkills: ["Data Structures", "Java/Python", "SQL", "System Design", "Object Oriented Programming"],
    missingSkills: ["Advanced DSA", "System Design", "Concurrency"],
    growthPotential: "Exceptional",
    topCompanies: ["Amazon", "Google", "Atlassian", "Goldman Sachs"]
  },
  {
    id: "c4",
    title: "Data Analyst / BI Specialist",
    matchScore: 78,
    salaryRange: "₹8 LPA - ₹16 LPA",
    demand: "High",
    description: "Extract actionable business insights from large datasets using SQL, Python data libraries, and interactive visualization tools.",
    skillBreakdown: {
      frontend: 50,
      backend: 60,
      database: 90,
      cloud: 50
    },
    requiredSkills: ["Python", "SQL", "Tableau/PowerBI", "Statistics", "Pandas"],
    missingSkills: ["Tableau", "Advanced Statistics"],
    growthPotential: "Steady",
    topCompanies: ["Deloitte", "KPMG", "Accenture", "Uber"]
  }
];

export const careerRoadmap = [
  {
    phase: 1,
    title: "Programming Fundamentals",
    status: "Completed",
    progress: 100,
    duration: "4 weeks",
    skills: ["Java Basics", "Object Oriented Programming", "Basic Algorithms"],
    tasks: [
      { id: "t1", title: "Master Java Syntax & Collections", completed: true },
      { id: "t2", title: "Implement OOP design principles", completed: true },
      { id: "t3", title: "Solve 50+ basic algorithmic problems", completed: true }
    ],
    projects: ["Student Management Console App", "Banking System Simulator"]
  },
  {
    phase: 2,
    title: "Frontend Development",
    status: "Completed",
    progress: 100,
    duration: "6 weeks",
    skills: ["HTML5/CSS3", "JavaScript ES6+", "React.js", "Tailwind CSS"],
    tasks: [
      { id: "t4", title: "Deep dive into Javascript closures & async/await", completed: true },
      { id: "t5", title: "Build SPAs using React Hooks & Context", completed: true },
      { id: "t6", title: "Responsive layouts with Tailwind CSS", completed: true }
    ],
    projects: ["E-Commerce Storefront", "Task Management Dashboard"]
  },
  {
    phase: 3,
    title: "Backend Development",
    status: "In Progress",
    progress: 65,
    duration: "5 weeks",
    skills: ["Node.js", "Express.js", "REST APIs", "PostgreSQL / MongoDB"],
    tasks: [
      { id: "t7", title: "Build robust RESTful APIs with Express", completed: true },
      { id: "t8", title: "Connect PostgreSQL with ORMs and write migrations", completed: true },
      { id: "t9", title: "Implement JWT Authentication and Security middleware", completed: false }
    ],
    projects: ["Real-time Chat Backend", "Blog REST API with Auth"]
  },
  {
    phase: 4,
    title: "Cloud & DevOps",
    status: "In Progress",
    progress: 20,
    duration: "4 weeks",
    skills: ["Docker", "AWS EC2/S3", "CI/CD Pipelines", "Linux Basics"],
    tasks: [
      { id: "t10", title: "Containerize web applications using Docker", completed: true },
      { id: "t11", title: "Deploy apps to AWS EC2 instance", completed: false },
      { id: "t12", title: "Set up GitHub Actions CI/CD workflows", completed: false }
    ],
    projects: ["Dockerized Full-Stack App Deployment"]
  },
  {
    phase: 5,
    title: "Interview Preparation",
    status: "Not Started",
    progress: 0,
    duration: "4 weeks",
    skills: ["Mock Interviews", "Resume Optimization", "Behavioral Prep", "System Design"],
    tasks: [
      { id: "t13", title: "Revise Top 150 LeetCode Interview Questions", completed: false },
      { id: "t14", title: "Conduct 3 AI & Peer Mock Interviews", completed: false },
      { id: "t15", title: "Finalize Resume & LinkedIn Profile", completed: false }
    ],
    projects: ["Placement Ready Portfolio Showcase"]
  }
];

export const jobsList = [
  {
    id: "j1",
    title: "Full Stack Software Engineer",
    company: "TechNova Solutions",
    logoBg: "bg-blue-600",
    location: "Bengaluru",
    workMode: "Hybrid",
    salary: "₹15 LPA - ₹22 LPA",
    stipend: null,
    type: "Full-time",
    requiredSkills: ["React", "Node.js", "SQL", "Git"],
    postedDate: "2 days ago",
    matchScore: 92,
    description: "We are looking for a passionate Full Stack Engineer to build next-generation cloud analytics dashboards and high-throughput microservices."
  },
  {
    id: "j2",
    title: "Frontend Developer",
    company: "PixelCraft Labs",
    logoBg: "bg-purple-600",
    location: "Remote",
    workMode: "Remote",
    salary: "₹12 LPA - ₹18 LPA",
    stipend: null,
    type: "Full-time",
    requiredSkills: ["React", "JavaScript", "Tailwind CSS", "TypeScript"],
    postedDate: "Yesterday",
    matchScore: 89,
    description: "Join our design-first engineering team to craft pixel-perfect user experiences used by millions of global creators."
  },
  {
    id: "j3",
    title: "Backend Engineer (Node.js)",
    company: "CloudScale Systems",
    logoBg: "bg-emerald-600",
    location: "Hyderabad",
    workMode: "On-site",
    salary: "₹14 LPA - ₹20 LPA",
    stipend: null,
    type: "Full-time",
    requiredSkills: ["Node.js", "Express", "PostgreSQL", "Docker"],
    postedDate: "3 days ago",
    matchScore: 78,
    description: "Scale our event-driven microservices architecture handling millions of real-time financial transactions daily."
  },
  {
    id: "j4",
    title: "Graduate Engineer Trainee",
    company: "Global Tech Corp",
    logoBg: "bg-amber-600",
    location: "Pune",
    workMode: "Hybrid",
    salary: "₹8 LPA - ₹12 LPA",
    stipend: null,
    type: "Full-time",
    requiredSkills: ["Java", "SQL", "Data Structures", "Problem Solving"],
    postedDate: "1 week ago",
    matchScore: 84,
    description: "Comprehensive 6-month rotational training program leading to a permanent software engineering role in enterprise systems."
  }
];

export const internshipsList = [
  {
    id: "i1",
    title: "Frontend Developer Intern",
    company: "InnoVibe Technologies",
    logoBg: "bg-indigo-600",
    location: "Bengaluru",
    workMode: "Hybrid",
    salary: null,
    stipend: "₹35,000 / month",
    type: "Internship",
    requiredSkills: ["React", "JavaScript", "Git", "Tailwind CSS"],
    postedDate: "Today",
    matchScore: 94,
    description: "Work directly with senior UI architects on interactive component libraries and high-speed web application frontends."
  },
  {
    id: "i2",
    title: "Software Engineering Intern",
    company: "DataPulse AI",
    logoBg: "bg-rose-600",
    location: "Bengaluru",
    workMode: "Remote",
    salary: null,
    stipend: "₹40,000 / month",
    type: "Internship",
    requiredSkills: ["Python", "SQL", "React", "REST APIs"],
    postedDate: "2 days ago",
    matchScore: 88,
    description: "Build internal developer tooling and AI-powered data pipelines supporting our core machine learning infrastructure."
  },
  {
    id: "i3",
    title: "Full Stack Intern",
    company: "NextGen SaaS",
    logoBg: "bg-cyan-600",
    location: "Chennai",
    workMode: "On-site",
    salary: null,
    stipend: "₹25,000 / month",
    type: "Internship",
    requiredSkills: ["React", "Node.js", "JavaScript", "SQL"],
    postedDate: "4 days ago",
    matchScore: 82,
    description: "Fast-paced product internship with potential PPO (Pre-Placement Offer) upon successful completion."
  }
];

export const applicationsList = [
  {
    id: "app1",
    role: "Frontend Developer Intern",
    company: "InnoVibe Technologies",
    appliedDate: "Feb 24, 2026",
    status: "Interview",
    stipend: "₹35K/mo",
    location: "Bengaluru",
    timeline: [
      { stage: "Applied", date: "Feb 24", completed: true },
      { stage: "Assessment", date: "Feb 28", completed: true },
      { stage: "Interview", date: "Mar 04", completed: true, current: true },
      { stage: "Selected", date: "Pending", completed: false }
    ]
  },
  {
    id: "app2",
    role: "Full Stack Software Engineer",
    company: "TechNova Solutions",
    appliedDate: "Feb 20, 2026",
    status: "Assessment",
    stipend: "₹18 LPA",
    location: "Bengaluru",
    timeline: [
      { stage: "Applied", date: "Feb 20", completed: true },
      { stage: "Assessment", date: "Mar 02", completed: true, current: true },
      { stage: "Interview", date: "Pending", completed: false },
      { stage: "Selected", date: "Pending", completed: false }
    ]
  },
  {
    id: "app3",
    role: "Software Engineering Intern",
    company: "DataPulse AI",
    appliedDate: "Feb 15, 2026",
    status: "Applied",
    stipend: "₹40K/mo",
    location: "Remote",
    timeline: [
      { stage: "Applied", date: "Feb 15", completed: true, current: true },
      { stage: "Assessment", date: "Pending", completed: false },
      { stage: "Interview", date: "Pending", completed: false },
      { stage: "Selected", date: "Pending", completed: false }
    ]
  },
  {
    id: "app4",
    role: "Graduate Engineer Trainee",
    company: "Global Tech Corp",
    appliedDate: "Feb 01, 2026",
    status: "Selected",
    stipend: "₹10 LPA",
    location: "Pune",
    timeline: [
      { stage: "Applied", date: "Feb 01", completed: true },
      { stage: "Assessment", date: "Feb 08", completed: true },
      { stage: "Interview", date: "Feb 18", completed: true },
      { stage: "Selected", date: "Feb 22", completed: true, current: true }
    ]
  }
];

export const initialChatMessages = [
  {
    id: "m1",
    sender: "ai",
    text: "Hello Arjun! 👋 I am your AI Career & Placement Agent. Based on your 8.4 CGPA in Computer Science and 90% proficiency in React, your profile is looking strong for Full Stack & Frontend roles. How can I help accelerate your career today?",
    timestamp: "10:00 AM"
  },
  {
    id: "m2",
    sender: "user",
    text: "What should I focus on most to clear product-based company interviews in the next 2 months?",
    timestamp: "10:01 AM"
  },
  {
    id: "m3",
    sender: "ai",
    text: "Great question! To target top product companies (like Zomato, Razorpay, and Microsoft), prioritize 3 key areas:\n\n1. **Data Structures & Algorithms**: Focus on Trees, Graphs, and Dynamic Programming (solve at least 3-4 LeetCode problems daily).\n2. **Backend Architecture**: Since your Node.js score is 60%, complete Phase 3 of your roadmap to master REST APIs, middleware, and database indexing.\n3. **System Design**: Learn basic scalability concepts, load balancing, and caching strategies.\n\nWould you like me to generate a personalized 60-day sprint checklist for this?",
    timestamp: "10:01 AM"
  }
];

export const notificationsList = [
  {
    id: "n1",
    title: "New Job Match Found",
    description: "TechNova Solutions posted a Full Stack Engineer role matching 92% of your profile.",
    time: "10 mins ago",
    read: false,
    type: "job"
  },
  {
    id: "n2",
    title: "Roadmap Milestone Completed",
    description: "Congratulations on completing 'Frontend Development' phase!",
    time: "3 hours ago",
    read: false,
    type: "roadmap"
  },
  {
    id: "n3",
    title: "AI Career Recommendation Updated",
    description: "Your match for 'Full Stack Developer' increased by +4% based on your latest React project.",
    time: "Yesterday",
    read: true,
    type: "ai"
  },
  {
    id: "n4",
    title: "Interview Reminder",
    description: "Upcoming technical interview with InnoVibe Technologies on March 4, 2026.",
    time: "2 days ago",
    read: true,
    type: "interview"
  }
];

export const projectsList = [
  {
    id: "p1",
    name: "AI Code Review Assistant",
    description: "Full-stack SaaS application that leverages LLMs to perform automated code quality checks, security vulnerability scanning, and refactoring suggestions.",
    technologies: ["React", "Node.js", "Tailwind CSS", "Google GenAI SDK", "Express"],
    role: "Full Stack Developer",
    github: "https://github.com/arjunreddy/ai-code-review",
    demo: "https://ai-code-review-demo.dev"
  },
  {
    id: "p2",
    name: "Campus Connect Social Network",
    description: "Real-time campus community platform with discussion forums, event ticketing, peer mentoring channels, and automated notification webhooks.",
    technologies: ["React", "Socket.io", "Node.js", "PostgreSQL"],
    role: "Lead Frontend Engineer",
    github: "https://github.com/arjunreddy/campus-connect",
    demo: "https://campusconnect.dev"
  },
  {
    id: "p3",
    name: "Distributed E-Commerce Microservices",
    description: "High-performance microservices architecture handling product catalogs, secure cart sessions, and payment gateway webhooks.",
    technologies: ["Java", "Spring Boot", "Docker", "PostgreSQL", "Redis"],
    role: "Backend Architect",
    github: "https://github.com/arjunreddy/ecommerce-microservices",
    demo: "https://github.com/arjunreddy/ecommerce-microservices"
  }
];

export const certificationsList = [
  { id: "cert1", title: "AWS Certified Cloud Practitioner", issuer: "Amazon Web Services", date: "Jan 2026", credentialId: "AWS-CCP-892341" },
  { id: "cert2", title: "Advanced React & Redux", issuer: "Meta (Coursera)", date: "Nov 2025", credentialId: "META-ACT-55821" },
  { id: "cert3", title: "PostgreSQL Database Administration", issuer: "PostgreSQL Global Development Group", date: "Aug 2025", credentialId: "PG-DBA-9912" }
];

export const achievementsList = [
  { id: "ach1", title: "1st Place - National Hackathon 2025", description: "Built an AI emergency response router among 500+ competing college teams.", date: "Oct 2025" },
  { id: "ach2", title: "LeetCode 500+ Problems Solved", description: "Maintained a 120-day streak solving algorithm and data structure problems.", date: "Jan 2026" },
  { id: "ach3", title: "Merit Scholarship Award", description: "Awarded top 1% academic merit scholarship for consecutive academic years.", date: "Jul 2025" }
];

export const dashboardStats = {
  placementReadiness: 78,
  readinessGrowth: "+8% this month",
  profileCompletion: 82,
  careerMatch: 92,
  skillScore: 72,
  skillScoreGrowth: "+5% this month",
  activeApplications: 4,
  interviewsScheduled: 1
};
