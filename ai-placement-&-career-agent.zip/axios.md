# CareerAI - Frontend Axios API Documentation (`axios.md`)

This document provides a comprehensive specification of all frontend API endpoints, Axios client configuration, request/response schemas, fallback handlers, and backend integration requirements for the **CareerAI** application.

---

## 1. Axios Client Configuration

The centralized Axios client instance is configured in `/src/services/api.js`.

### Client Setup
```javascript
// File: /src/services/api.js
import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api",
  headers: {
    "Content-Type": "application/json"
  },
  timeout: 10000 // 10s default timeout
});

export default api;
```

### Environment Variables
| Variable | Default Value | Description |
| :--- | :--- | :--- |
| `VITE_API_BASE_URL` | `http://localhost:5000/api` | Base URL for all backend REST API endpoints |

### Graceful Fallback Architecture
All service functions implement a **resilient `try/catch` fallback pattern**. If the backend server is offline, returns a 4xx/5xx error, or fails network connectivity, the frontend automatically falls back to the curated dataset in `/src/data/data.js`. This guarantees that the UI continues functioning smoothly without blank screens or crashes.

---

## 2. API Endpoints Master Table

| Method | Endpoint | Service File | Frontend Function | Description | Fallback Available |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **GET** | `/dashboard` | `dashboardApi.js` | `getDashboard()` | Aggregated dashboard stats, top recommendation, gaps, roadmap | Yes |
| **GET** | `/career/recommendations` | `careerApi.js` | `getCareerRecommendations()` | AI-matched career tracks, match scores, CTC, hiring companies | Yes |
| **GET** | `/skills` | `skillsApi.js` | `getSkills()` | Student technical skills, proficiency levels, and gap priorities | Yes |
| **GET** | `/roadmap` | `roadmapApi.js` | `getRoadmap()` | Multi-phase learning roadmap with milestone checklist | Yes |
| **PATCH** | `/roadmap/phase/:phaseId/task/:taskId` | `roadmapApi.js` | `updateTaskStatus(phaseId, taskId, completed)` | Updates a specific roadmap task's completion status | Yes |
| **GET** | `/jobs` | `jobsApi.js` | `getJobs()` | Curated full-time tech placement opportunities | Yes |
| **GET** | `/internships` | `jobsApi.js` | `getInternships()` | High-stipend summer & semester internship listings | Yes |
| **GET** | `/applications` | `jobsApi.js` | `getApplications()` | Tracks student job/internship application statuses | Yes |
| **POST** | `/applications` | `jobsApi.js` | `applyToOpportunity(opportunityId)` | Submits a new job/internship application | Yes |
| **POST** | `/chat` | `chatbotApi.js` | `sendMessage(messageText)` | Interactive AI career mentor dialogue & instant responses | Yes (NLP Matcher) |
| **GET** | `/profile` | `profileApi.js` | `getStudentProfile()` | Full student profile, CGPA, academic history, projects | Yes |
| **PUT** | `/profile` | `profileApi.js` | `updateStudentProfile(profileData)` | Updates student profile, social links, bio, and portfolio | Yes |
| **POST** | `/auth/login` | `LoginPage.jsx` | `handleSubmit()` | Student authentication via University USN & Password | Simulated |
| **POST** | `/auth/register` | `LoginPage.jsx` | `handleSubmit()` | New student registration with USN and college credentials | Simulated |
| **POST** | `/auth/google` | `LoginPage.jsx` | `handleGoogleLogin()` | Google Workspace institutional Single Sign-On (SSO) | Simulated |

---

## 3. Detailed Endpoint Specifications

### 3.1 Dashboard Service (`/src/services/dashboardApi.js`)

#### `GET /dashboard`
Retrieves aggregated statistics and student readiness overview.

- **Request:**
  ```http
  GET /api/dashboard HTTP/1.1
  Host: localhost:5000
  Content-Type: application/json
  ```
- **Response (`200 OK`):**
  ```json
  {
    "stats": {
      "placementReadiness": 84,
      "skillsVerified": 11,
      "skillGapsIdentified": 4,
      "roadmapProgress": 65,
      "activeApplications": 4,
      "interviewsScheduled": 1,
      "cgpa": 8.4,
      "backlogs": 0
    },
    "recommendedCareer": {
      "id": 1,
      "title": "Full Stack Developer",
      "matchPercentage": 92,
      "badge": "Top Match",
      "averageSalary": "₹8 - 14 LPA",
      "demandLevel": "Very High"
    },
    "skillGaps": [
      {
        "skill": "Node.js & Express",
        "currentLevel": 60,
        "requiredLevel": 85,
        "priority": "Critical",
        "estimatedTime": "3 weeks"
      }
    ],
    "roadmapProgress": [
      { "id": 1, "phase": "Phase 1: Foundations & CS Core", "progress": 100, "status": "Completed" },
      { "id": 2, "phase": "Phase 2: Frontend Specialization", "progress": 100, "status": "Completed" },
      { "id": 3, "phase": "Phase 3: Backend & APIs", "progress": 65, "status": "In Progress" }
    ],
    "recommendedOpportunities": [
      {
        "id": 101,
        "role": "Frontend Developer Intern",
        "company": "InnoVibe Technologies",
        "match": 94,
        "stipend": "₹35,000 / mo"
      }
    ]
  }
  ```

---

### 3.2 Career Recommendations Service (`/src/services/careerApi.js`)

#### `GET /career/recommendations`
Retrieves AI-matched career tracks based on student tech stack and academic background.

- **Request:**
  ```http
  GET /api/career/recommendations HTTP/1.1
  ```
- **Response (`200 OK`):**
  ```json
  [
    {
      "id": 1,
      "title": "Full Stack Developer",
      "matchPercentage": 92,
      "badge": "Top Match",
      "demandLevel": "Very High",
      "averageSalary": "₹8 - 14 LPA",
      "overview": "Build scalable client and server-side web applications using React, Node.js, and modern databases.",
      "requiredSkills": ["React.js", "Node.js & Express", "SQL & Databases", "System Design"],
      "topHiringCompanies": ["Amazon", "Flipkart", "Swiggy", "Razorpay"],
      "industryOutlook": "Strong market demand with a 24% annual growth in placement opportunities."
    },
    {
      "id": 2,
      "title": "Frontend Engineer",
      "matchPercentage": 90,
      "badge": "High Match",
      "demandLevel": "High",
      "averageSalary": "₹7 - 12 LPA",
      "overview": "Specialize in crafting interactive, high-performance web and mobile UI systems.",
      "requiredSkills": ["React.js", "JavaScript / ES6+", "Tailwind CSS", "TypeScript"],
      "topHiringCompanies": ["Zoho", "Freshworks", "Cred", "PhonePe"],
      "industryOutlook": "Consistent hiring across Tier-1 and Tier-2 product startups."
    }
  ]
  ```

---

### 3.3 Skills & Diagnostic Gap Service (`/src/services/skillsApi.js`)

#### `GET /skills`
Retrieves verified student competencies, level badges, and prioritized technical skill gaps.

- **Request:**
  ```http
  GET /api/skills HTTP/1.1
  ```
- **Response (`200 OK`):**
  ```json
  {
    "overallScore": 72,
    "skills": [
      {
        "name": "React.js",
        "category": "Web Development",
        "level": 90,
        "industryReq": 90,
        "priority": "Good",
        "currentLevelBadge": "Advanced",
        "targetLevel": "Advanced"
      },
      {
        "name": "Node.js & Express",
        "category": "Web Development",
        "level": 60,
        "industryReq": 85,
        "priority": "Critical",
        "currentLevelBadge": "Beginner",
        "targetLevel": "Advanced"
      }
    ],
    "skillGaps": [
      {
        "skill": "Node.js & Express",
        "currentLevel": 60,
        "requiredLevel": 85,
        "priority": "Critical",
        "estimatedTime": "3 weeks",
        "recommendedResource": "Node.js Microservices Masterclass (Coursera / Udemy)",
        "category": "Web Development"
      },
      {
        "skill": "System Design",
        "currentLevel": 45,
        "requiredLevel": 80,
        "priority": "Critical",
        "estimatedTime": "4 weeks",
        "recommendedResource": "Designing Data-Intensive Applications & System Design Primer",
        "category": "Architecture"
      }
    ]
  }
  ```

---

### 3.4 Roadmap Service (`/src/services/roadmapApi.js`)

#### `GET /roadmap`
Fetches multi-phase milestone roadmaps.

- **Request:**
  ```http
  GET /api/roadmap HTTP/1.1
  ```
- **Response (`200 OK`):**
  ```json
  [
    {
      "id": 1,
      "phase": "Phase 1: Foundations & CS Core",
      "timeline": "Weeks 1 - 4",
      "status": "Completed",
      "progress": 100,
      "tasks": [
        { "id": "t1", "title": "Data Structures in Java / Python", "completed": true },
        { "id": "t2", "title": "Operating Systems & Concurrency", "completed": true }
      ]
    },
    {
      "id": 3,
      "phase": "Phase 3: Backend & APIs",
      "timeline": "Weeks 9 - 14",
      "status": "In Progress",
      "progress": 65,
      "tasks": [
        { "id": "t6", "title": "REST APIs with Express & JWT Auth", "completed": true },
        { "id": "t7", "title": "PostgreSQL & Database Migrations", "completed": false }
      ]
    }
  ]
  ```

#### `PATCH /roadmap/phase/:phaseId/task/:taskId`
Updates completion status of a specific task item.

- **Request:**
  ```http
  PATCH /api/roadmap/phase/3/task/t7 HTTP/1.1
  Content-Type: application/json

  {
    "completed": true
  }
  ```
- **Response (`200 OK`):**
  ```json
  {
    "success": true,
    "phaseId": 3,
    "taskId": "t7",
    "completed": true,
    "phaseProgress": 85
  }
  ```

---

### 3.5 Jobs, Internships & Applications Service (`/src/services/jobsApi.js`)

#### `GET /jobs`
Fetches active full-time job postings.

- **Response (`200 OK`):**
  ```json
  [
    {
      "id": 1,
      "title": "Software Development Engineer 1 (SDE-1)",
      "company": "TechNova Solutions",
      "location": "Bengaluru, India (Hybrid)",
      "type": "Full-Time",
      "ctc": "₹12 - 16 LPA",
      "matchPercentage": 92,
      "skillsRequired": ["React.js", "Node.js", "PostgreSQL", "Docker"],
      "eligibility": "B.Tech CSE/IT with CGPA >= 7.5",
      "deadline": "2026-10-15"
    }
  ]
  ```

#### `GET /internships`
Fetches summer and semester internship listings.

- **Response (`200 OK`):**
  ```json
  [
    {
      "id": 101,
      "title": "Frontend Engineering Intern",
      "company": "InnoVibe Technologies",
      "location": "Remote / Hyderabad",
      "type": "Internship",
      "duration": "6 Months",
      "stipend": "₹35,000 / month",
      "matchPercentage": 94,
      "skillsRequired": ["React.js", "Tailwind CSS", "REST APIs"],
      "eligibility": "3rd / 4th Year Undergrads",
      "deadline": "2026-09-30"
    }
  ]
  ```

#### `GET /applications`
Fetches the student's submitted application history and status.

- **Response (`200 OK`):**
  ```json
  [
    {
      "id": 1,
      "role": "Frontend Engineering Intern",
      "company": "InnoVibe Technologies",
      "appliedDate": "2026-08-28",
      "status": "Shortlisted",
      "statusColor": "teal",
      "nextStep": "Technical Round scheduled for Sep 5, 2026"
    }
  ]
  ```

#### `POST /applications`
Submits a student application for an opportunity.

- **Request:**
  ```http
  POST /api/applications HTTP/1.1
  Content-Type: application/json

  {
    "opportunityId": 101
  }
  ```
- **Response (`201 Created`):**
  ```json
  {
    "success": true,
    "applicationId": "APP-2026-8942",
    "message": "Application submitted successfully to InnoVibe Technologies."
  }
  ```

---

### 3.6 AI Placement Chatbot Service (`/src/services/chatbotApi.js`)

#### `POST /chat`
Submits student questions to the AI Career Mentor.

- **Request:**
  ```http
  POST /api/chat HTTP/1.1
  Content-Type: application/json

  {
    "message": "What are my top skill gaps for Full Stack Developer?"
  }
  ```
- **Response (`200 OK`):**
  ```json
  {
    "reply": "Your primary skill gaps are Node.js & Express (currently 60% vs 85% required) and System Design (45% vs 80% required). Completing Phase 3 of your roadmap will boost your placement readiness to 96%.",
    "timestamp": "10:45 AM"
  }
  ```

---

### 3.7 Student Profile & Academics Service (`/src/services/profileApi.js`)

#### `GET /profile`
Retrieves comprehensive student profile details.

- **Response (`200 OK`):**
  ```json
  {
    "profile": {
      "name": "Arjun Reddy",
      "email": "arjun.reddy@example.com",
      "phone": "+91 98765 43210",
      "branch": "Computer Science Engineering",
      "year": "3rd Year",
      "semester": "6th Semester",
      "cgpa": 8.4,
      "college": "ABC Institute of Technology & Science",
      "location": "Bengaluru, India",
      "profileCompletion": 82,
      "backlogs": 0,
      "github": "https://github.com/arjunreddy",
      "linkedin": "https://linkedin.com/in/arjunreddy",
      "portfolio": "https://arjunreddy.dev",
      "resumeUploaded": true,
      "resumeFileName": "Arjun_Reddy_Resume_2026.pdf",
      "bio": "Passionate CS undergrad specializing in full-stack web engineering, distributed systems, and AI-driven applications."
    },
    "academicPerformance": [
      { "semester": "Sem 1", "cgpa": 8.1, "average": 7.5 },
      { "semester": "Sem 2", "cgpa": 8.3, "average": 7.6 },
      { "semester": "Sem 3", "cgpa": 8.0, "average": 7.4 },
      { "semester": "Sem 4", "cgpa": 8.5, "average": 7.7 },
      { "semester": "Sem 5", "cgpa": 8.8, "average": 7.8 }
    ],
    "skills": [...],
    "projects": [...],
    "certifications": [...],
    "achievements": [...]
  }
  ```

#### `PUT /profile`
Updates student details, bio, links, and resume info.

- **Request:**
  ```http
  PUT /api/profile HTTP/1.1
  Content-Type: application/json

  {
    "portfolio": "https://arjunreddy.dev",
    "github": "https://github.com/arjunreddy",
    "linkedin": "https://linkedin.com/in/arjunreddy",
    "bio": "Updated CS undergrad bio with new hackathon awards."
  }
  ```
- **Response (`200 OK`):**
  ```json
  {
    "success": true,
    "message": "Profile updated successfully",
    "profile": {
      "name": "Arjun Reddy",
      "portfolio": "https://arjunreddy.dev"
    }
  }
  ```

---

## 4. HTTP Status Code Guidelines

| HTTP Code | Name | Scenario |
| :--- | :--- | :--- |
| `200 OK` | Standard Success | Resource fetched or updated successfully |
| `201 Created` | Creation Success | Application submitted or student registered |
| `400 Bad Request` | Validation Error | Missing required fields (e.g., missing USN, invalid email) |
| `401 Unauthorized` | Auth Required | Invalid credentials or expired session token |
| `404 Not Found` | Resource Missing | Job ID or roadmap task ID not found |
| `500 Server Error` | Backend Failure | Unhandled backend exception (triggers frontend fallback) |

---

## 5. Instructions for Backend Engineers

1. **CORS Configuration**: Enable Cross-Origin Resource Sharing for your frontend domain (e.g., `http://localhost:3000` or the Cloud Run URL).
2. **Mount Path**: Ensure your API routes are mounted under the `/api` prefix (e.g., `app.use('/api', apiRouter)` in Express).
3. **Authentication Header**: When implementing Bearer JWTs, intercept requests using Axios request interceptor in `/src/services/api.js`:
   ```javascript
   api.interceptors.request.use((config) => {
     const token = localStorage.getItem("auth_token");
     if (token) {
       config.headers.Authorization = `Bearer ${token}`;
     }
     return config;
   });
   ```
